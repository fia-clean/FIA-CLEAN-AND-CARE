/**
 * FIA CLEAN & CARE - Operations: Stock & Product Management Module
 * Handles Cleaning & Cosmetic products, packaging inventory, variants, stock returns, and consolidation.
 */

import {
    state,
    sortByNameAsc,
    todayDDMMYYYY,
    saveLocalStateSafely,
    markIdDeleted,
    unmarkIdDeleted,
    markRecordDeleted,
    toTitleCase,
    generateUniqueRecordId
} from '../core/state.js';
import { syncToFirebase, pullFromFirebase } from '../core/db.js';
import { getProductWholesalePrice, getProductRetailPrice, updateProductDropdown, updateCombinedProductSelect, updateBillQuantityTypeDropdown } from '../billing/billing.js';

export function updatePackageSelectors() {
    const opts = '<option value="">No Package Mapping</option>' + sortByNameAsc(state.packages).map(x => `<option value="${String(x.id)}">${x.name}${x.size ? ' — ' + x.size : ''} (Stock: ${x.stock} ${x.unit || 'Pcs'})</option>`).join('');
    ['prodPackageId', 'cosProdPackageId'].forEach(id => {
        const el = document.getElementById(id); if (!el) return;
        const old = String(el.value || '');
        el.innerHTML = opts;
        el.value = (old && [...el.options].some(o => String(o.value) === old)) ? old : '';
    });
    // Update open variant row package dropdowns if any exist
    document.querySelectorAll('.var-pkg').forEach(sel => {
        const oldVal = sel.value;
        sel.innerHTML = '<option value="">-- Container Package --</option>' + sortByNameAsc(state.packages).map(p => `<option value="${p.id}">${p.name}${p.size ? ' (' + p.size + ')' : ''} (Stock: ${p.stock})</option>`).join('');
        if (oldVal && [...sel.options].some(o => o.value === oldVal)) sel.value = oldVal;
    });
    if (typeof updateBillQuantityTypeDropdown === 'function') updateBillQuantityTypeDropdown();
    if (typeof updateProductDropdown === 'function') updateProductDropdown();
    if (typeof updateCombinedProductSelect === 'function') updateCombinedProductSelect();
}

// ================= PACK SIZE & PRICING VARIANT HELPERS =================
export function addProductVariantRow(target = 'cleaning', data = null) {
    const containerId = target === 'cosmetics' ? 'cosProductVariantsContainer' : 'productVariantsContainer';
    const container = document.getElementById(containerId);
    if (!container) return;

    const v = data || {
        id: 'var_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
        name: '',
        size: '',
        unit: target === 'cosmetics' ? 'ml' : 'Ltr',
        packageId: '',
        packageName: '',
        wholesalePrice: '',
        retailPrice: ''
    };

    const pkgOptions = '<option value="">-- Container Package --</option>' +
        sortByNameAsc(state.packages).map(p => `<option value="${p.id}" ${String(p.id) === String(v.packageId) ? 'selected' : ''}>${p.name}${p.size ? ' (' + p.size + ')' : ''} (Stock: ${p.stock})</option>`).join('');

    const row = document.createElement('div');
    row.className = 'prod-variant-row bg-slate-950 p-3 rounded-2xl border border-slate-700/90 space-y-2.5 shadow-sm';
    row.dataset.varId = v.id;
    row.innerHTML = `
        <div class="flex justify-between items-center gap-2">
            <span class="text-[11px] font-extrabold ${target === 'cosmetics' ? 'text-pink-300' : 'text-emerald-300'}">📦 Pack Variant</span>
            <button type="button" onclick="this.closest('.prod-variant-row').remove()" class="bg-red-950/80 hover:bg-red-900 text-red-300 px-2 py-0.5 rounded-lg text-[10px] font-bold border border-red-800" title="Delete Variant">✕ Remove</button>
        </div>
        <div>
            <label class="text-[10px] text-slate-400 block mb-0.5 font-semibold">Pack Name (e.g. 500 ml Bottle, 1 Ltr Can)</label>
            <input type="text" class="var-name w-full p-2 bg-slate-900 border border-slate-700 rounded-xl text-xs ${target === 'cosmetics' ? 'text-pink-300' : 'text-emerald-300'} font-bold focus:outline-none focus:border-emerald-500" placeholder="Pack Name (e.g. 500 ml Bottle)" value="${String(v.name || '').replace(/"/g, '&quot;')}">
        </div>
        <div class="grid grid-cols-2 gap-2">
            <div>
                <label class="text-[10px] text-slate-400 block mb-0.5 font-semibold">Volume / Size:</label>
                <div class="flex gap-1">
                    <input type="number" class="var-size w-3/5 p-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white font-bold focus:outline-none focus:border-emerald-500" placeholder="Size" value="${v.size || ''}" min="0" step="any">
                    <select class="var-unit w-2/5 p-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none">
                        <option value="ml" ${v.unit === 'ml' ? 'selected' : ''}>ml</option>
                        <option value="Ltr" ${v.unit === 'Ltr' ? 'selected' : ''}>Ltr</option>
                        <option value="g" ${v.unit === 'g' ? 'selected' : ''}>g</option>
                        <option value="Kg" ${v.unit === 'Kg' ? 'selected' : ''}>Kg</option>
                        <option value="mg" ${v.unit === 'mg' ? 'selected' : ''}>mg</option>
                        <option value="Pcs" ${v.unit === 'Pcs' ? 'selected' : ''}>Pcs</option>
                        <option value="Bottle" ${v.unit === 'Bottle' ? 'selected' : ''}>Bottle</option>
                        <option value="General" ${v.unit === 'General' ? 'selected' : ''}>General</option>
                    </select>
                </div>
            </div>
            <div>
                <label class="text-[10px] text-cyan-300 block mb-0.5 font-semibold">🧴 Package Container:</label>
                <select class="var-pkg w-full p-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-cyan-200 focus:outline-none focus:border-cyan-500">
                    ${pkgOptions}
                </select>
            </div>
        </div>
        <div class="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800/80">
            <div>
                <label class="text-[10px] text-emerald-400 block mb-0.5 font-extrabold">Retail Price (₹):</label>
                <input type="number" class="var-retail w-full p-2 bg-slate-900 border border-emerald-600/70 rounded-xl text-xs text-emerald-300 font-black focus:outline-none focus:border-emerald-400" placeholder="Enter Retail Price" value="${v.retailPrice !== undefined && v.retailPrice !== '' ? v.retailPrice : ''}" min="0" step="any">
            </div>
            <div>
                <label class="text-[10px] text-amber-400 block mb-0.5 font-extrabold">Wholesale Price (₹):</label>
                <input type="number" class="var-wholesale w-full p-2 bg-slate-900 border border-amber-600/70 rounded-xl text-xs text-amber-300 font-black focus:outline-none focus:border-amber-400" placeholder="Enter Wholesale Price" value="${v.wholesalePrice !== undefined && v.wholesalePrice !== '' ? v.wholesalePrice : ''}" min="0" step="any">
            </div>
        </div>`;
    container.appendChild(row);
}

export function addPresetProductVariant(name, size, unit, target = 'cleaning') {
    let matchedPkg = null;
    const normName = name.toLowerCase();
    const normSize = String(size).toLowerCase();
    matchedPkg = state.packages.find(p => {
        const pn = (p.name || '').toLowerCase();
        const ps = (p.size || '').toLowerCase();
        const sizeMatch = pn.includes(normSize) || ps.includes(normSize);
        const isBottle = normName.includes('bottle') && pn.includes('bottle');
        const isPouch = normName.includes('pouch') && pn.includes('pouch');
        const isCan = normName.includes('can') && pn.includes('can');
        return sizeMatch && (isBottle || isPouch || isCan);
    }) || state.packages.find(p => {
        const pn = (p.name || '').toLowerCase();
        return pn.includes(normSize);
    });

    addProductVariantRow(target, {
        id: 'var_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
        name,
        size,
        unit,
        packageId: matchedPkg ? matchedPkg.id : '',
        packageName: matchedPkg ? matchedPkg.name : '',
        wholesalePrice: '',
        retailPrice: ''
    });
}

export function getProductFormVariants(target = 'cleaning') {
    const containerId = target === 'cosmetics' ? 'cosProductVariantsContainer' : 'productVariantsContainer';
    const container = document.getElementById(containerId);
    if (!container) return [];
    const rows = container.querySelectorAll('.prod-variant-row');
    const list = [];
    rows.forEach(r => {
        const name = r.querySelector('.var-name')?.value.trim();
        const size = parseFloat(r.querySelector('.var-size')?.value) || 0;
        const unit = r.querySelector('.var-unit')?.value || 'ml';
        const pkgSelect = r.querySelector('.var-pkg');
        const packageId = pkgSelect?.value || '';
        const pkgOpt = pkgSelect?.selectedOptions?.[0];
        const packageName = pkgOpt && packageId ? pkgOpt.text.split(' (Stock:')[0].trim() : '';
        const wholesalePrice = parseFloat(r.querySelector('.var-wholesale')?.value) || 0;
        const retailPrice = parseFloat(r.querySelector('.var-retail')?.value) || 0;
        const varId = r.dataset.varId || ('var_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6));
        if (name && size > 0) {
            list.push({ id: varId, name, size, unit, packageId, packageName, wholesalePrice, retailPrice });
        }
    });
    return list;
}

export function renderProductVariants(variants, target = 'cleaning') {
    clearProductVariants(target);
    if (!Array.isArray(variants)) return;
    variants.forEach(v => addProductVariantRow(target, v));
}

export function clearProductVariants(target = 'cleaning') {
    const containerId = target === 'cosmetics' ? 'cosProductVariantsContainer' : 'productVariantsContainer';
    const container = document.getElementById(containerId);
    if (container) container.innerHTML = '';
}

export function normalizePackageMapping(packageId, packageQty, packageName) {
    const id = String(packageId || '').trim(), qty = Number(packageQty) || 0;
    let pkg = id ? state.packages.find(x => String(x.id) === id) : null;
    if (!pkg && packageName) {
        const nm = String(packageName).trim().toLowerCase();
        pkg = state.packages.find(x => String(x.name || '').trim().toLowerCase() === nm) || null;
    }
    return pkg && qty > 0 ? { packageId: String(pkg.id), packageQty: qty, packageName: String(pkg.name || '') } : { packageId: '', packageQty: 0, packageName: '' };
}

export function switchPackageActionTab(tab) {
    const addContent = document.getElementById('pkgStockAddContent');
    const viewContent = document.getElementById('pkgStockViewContent');
    const consContent = document.getElementById('pkgStockConsolidatedContent');
    const addTab = document.getElementById('pkgStockAddTab');
    const viewTab = document.getElementById('pkgStockViewTab');
    const consTab = document.getElementById('pkgStockConsolidatedTab');

    [addContent, viewContent, consContent].forEach(el => el && el.classList.add('hidden'));
    [addTab, viewTab, consTab].forEach(btn => {
        if (btn) {
            btn.classList.remove('bg-cyan-700', 'text-white', 'shadow-md');
            btn.classList.add('text-slate-400');
        }
    });

    if (tab === 'view') {
        if (viewContent) viewContent.classList.remove('hidden');
        if (viewTab) {
            viewTab.classList.add('bg-cyan-700', 'text-white', 'shadow-md');
            viewTab.classList.remove('text-slate-400');
        }
        renderPackages();
    } else if (tab === 'consolidated') {
        if (consContent) consContent.classList.remove('hidden');
        if (consTab) {
            consTab.classList.add('bg-cyan-700', 'text-white', 'shadow-md');
            consTab.classList.remove('text-slate-400');
        }
        renderPackageConsolidationReport();
    } else {
        if (addContent) addContent.classList.remove('hidden');
        if (addTab) {
            addTab.classList.add('bg-cyan-700', 'text-white', 'shadow-md');
            addTab.classList.remove('text-slate-400');
        }
    }
}

export function switchStockTopTab(tab) {
    if (typeof pullFromFirebase === 'function') pullFromFirebase();
    const productArea = document.getElementById('stockProductArea');
    const packageArea = document.getElementById('stockPackageArea');
    const p = document.getElementById('stockTopProduct');
    const q = document.getElementById('stockTopPackage');
    if (tab === 'package') {
        productArea?.classList.add('hidden');
        packageArea?.classList.remove('hidden');
        p?.classList.remove('bg-emerald-700', 'text-white', 'shadow-md');
        p?.classList.add('text-slate-400');
        q?.classList.add('bg-cyan-700', 'text-white', 'shadow-md');
        q?.classList.remove('text-slate-400');
        renderPackages();
        updatePackageSelectors();
        switchPackageActionTab(state.packages && state.packages.length > 0 ? 'view' : 'add');
    } else {
        packageArea?.classList.add('hidden');
        productArea?.classList.remove('hidden');
        q?.classList.remove('bg-cyan-700', 'text-white', 'shadow-md');
        q?.classList.add('text-slate-400');
        p?.classList.add('bg-emerald-700', 'text-white', 'shadow-md');
        p?.classList.remove('text-slate-400');
    }
}

export function switchStockSubTab(tab) {
    if (typeof pullFromFirebase === 'function') pullFromFirebase();
    const cleaning = document.getElementById('stockCleaningContent');
    const cosmetics = document.getElementById('stockCosmeticsContent');
    const b1 = document.getElementById('subTabStockCleaning');
    const b2 = document.getElementById('subTabStockCosmetics');
    [cleaning, cosmetics].forEach(el => el && el.classList.add('hidden'));
    [b1, b2].forEach(btn => {
        if (btn) {
            btn.classList.remove('bg-emerald-700', 'bg-pink-700', 'text-white', 'shadow-md');
            btn.classList.add('text-slate-400');
        }
    });
    if (tab === 'cosmetics') {
        cosmetics?.classList.remove('hidden');
        b2?.classList.add('bg-pink-700', 'text-white', 'shadow-md');
        b2?.classList.remove('text-slate-400');
        renderCosProductStock();
        updateCosProductDropdowns();
        updateStockReturnDropdowns();
        renderStockReturnHistory();
        switchStockActionTab('cosmetics', 'add');
    } else {
        cleaning?.classList.remove('hidden');
        b1?.classList.add('bg-emerald-700', 'text-white', 'shadow-md');
        b1?.classList.remove('text-slate-400');
        renderProducts();
        updateStockReturnDropdowns();
        renderStockReturnHistory();
        switchStockActionTab('cleaning', 'add');
    }
}

export function switchStockActionTab(type, tab) {
    if (tab === 'view' || tab === 'consolidated') {
        if (typeof pullFromFirebase === 'function') pullFromFirebase();
    }
    const prefix = type === 'cosmetics' ? 'cos' : 'clean';
    const ids = ['add', 'view', 'return', 'consolidated'];
    ids.forEach(t => {
        const content = document.getElementById(prefix + 'Stock' + t.charAt(0).toUpperCase() + t.slice(1) + 'Content');
        const button = document.getElementById(prefix + 'Stock' + t.charAt(0).toUpperCase() + t.slice(1) + 'Tab');
        if (content) content.classList.toggle('hidden', t !== tab);
        if (button) {
            button.classList.remove('bg-emerald-700', 'bg-pink-700', 'text-white', 'shadow-md');
            button.classList.add('text-slate-400');
            if (t === tab) {
                button.classList.add(type === 'cosmetics' ? 'bg-pink-700' : 'bg-emerald-700', 'text-white', 'shadow-md');
                button.classList.remove('text-slate-400');
            }
        }
    });
    if (tab === 'view') {
        if (type === 'cosmetics') renderCosProductStock(); else renderProducts();
    } else if (tab === 'return') {
        updateStockReturnDropdowns();
        renderStockReturnHistory();
    } else if (tab === 'consolidated') {
        renderConsolidatedStockReport();
    }
}

export function savePackage(e) {
    e.preventDefault();
    const id = document.getElementById('packageId').value;
    const name = toTitleCase(document.getElementById('packageName').value.trim());
    const size = document.getElementById('packageSize').value.trim();
    const unit = document.getElementById('packageUnit').value;
    const stock = parseFloat(document.getElementById('packageStock').value) || 0;
    if (!name) return;
    const pkgId = id || ('pkg_' + Date.now());
    unmarkIdDeleted(pkgId);
    const stamp = Date.now();
    const data = { id: pkgId, name, size, unit, stock, savedAt: stamp };
    if (id) {
        const i = state.packages.findIndex(x => String(x.id) === String(id));
        if (i >= 0) state.packages[i] = { ...state.packages[i], ...data };
        else state.packages.push(data);
    } else {
        state.packages.push(data);
    }
    syncToFirebase();
    resetPackageForm();
    renderPackages();
    updatePackageSelectors();
    if (typeof updateProductDropdown === 'function') updateProductDropdown();
    if (typeof updateCombinedProductSelect === 'function') updateCombinedProductSelect();
    switchPackageActionTab('view');
    renderConsolidatedStockReport();
}

export function resetPackageForm() {
    const f = document.getElementById('packageForm');
    if (f) f.reset();
    document.getElementById('packageId').value = '';
    const btn = document.getElementById('packageSubmitBtn');
    if (btn) btn.textContent = '💾 Save Package';
    const title = document.querySelector('#pkgStockAddContent h2');
    if (title) title.textContent = '🧴 Add Package Item';
    const unitEl = document.getElementById('packageUnit');
    if (unitEl) unitEl.value = 'Pcs';
}

export function editPackage(id) {
    const pkg = state.packages.find(x => String(x.id) === String(id));
    if (!pkg) return;
    if (typeof window.switchTab === 'function') window.switchTab('stock', false);
    if (typeof window.switchStockTopTab === 'function') window.switchStockTopTab('package');
    switchPackageActionTab('add');
    document.getElementById('packageId').value = pkg.id;
    document.getElementById('packageName').value = pkg.name || '';
    document.getElementById('packageSize').value = pkg.size || '';
    document.getElementById('packageUnit').value = pkg.unit || 'Pcs';
    document.getElementById('packageStock').value = pkg.stock ?? 0;
    const btn = document.getElementById('packageSubmitBtn');
    if (btn) btn.textContent = '💾 Update Package';
    setTimeout(() => {
        const title = document.querySelector('#pkgStockAddContent h2');
        if (title) title.textContent = '✏️ Edit Package Item';
        document.getElementById('packageForm')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        document.getElementById('packageName')?.focus();
    }, 50);
}

export function deletePackage(id) {
    if (!id) return;
    const pkg = state.packages.find(x => String(x.id) === String(id));
    const name = pkg ? pkg.name : 'package item';
    if (!confirm(`Delete package item "${name}"?`)) return;
    if (pkg) markRecordDeleted(pkg, 'package');
    markIdDeleted(id);
    state.packages = state.packages.filter(x => String(x.id) !== String(id));
    const stamp = Date.now();
    state.products.forEach(p => { if (String(p.packageId) === String(id)) { p.packageId = ''; p.packageQty = 0; p.savedAt = stamp; } });
    state.cosProducts.forEach(p => { if (String(p.packageId) === String(id)) { p.packageId = ''; p.packageQty = 0; p.savedAt = stamp; } });
    saveLocalStateSafely();
    syncToFirebase();
    if (typeof window.renderAll === 'function') window.renderAll();
    renderPackages();
    switchPackageActionTab('view');
    renderConsolidatedStockReport();
}

export function addPackageStock(id, qty) {
    const x = state.packages.find(p => String(p.id) === String(id));
    if (!x || !(qty > 0)) return;
    x.stock = (Number(x.stock) || 0) + qty;
    x.savedAt = Date.now();
    syncToFirebase();
    renderPackages();
    updatePackageSelectors();
    renderConsolidatedStockReport();
}

export function renderPackages() {
    const c = document.getElementById('packageListContainer');
    if (!c) return;
    c.innerHTML = sortByNameAsc(state.packages).map(x => {
        const isLow = (Number(x.stock) || 0) <= 5;
        const statusBadge = isLow
            ? `<span class="bg-rose-950/80 text-rose-300 border border-rose-800/60 px-2 py-0.5 rounded text-[10px] font-bold uppercase whitespace-nowrap">⚠️ LOW STOCK: ${x.stock ?? 0} ${x.unit || 'Pcs'}</span>`
            : `<span class="bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 px-2 py-0.5 rounded text-[10px] font-bold uppercase whitespace-nowrap font-mono">✓ ${x.stock ?? 0} ${x.unit || 'Pcs'}</span>`;
        return `
        <div class="bg-slate-900/70 border border-slate-800 rounded-xl p-3.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 text-xs">
            <div class="min-w-0 flex-1 pr-2 break-words">
                <div class="flex items-center gap-2 flex-wrap">
                    <p class="font-bold text-cyan-300 text-sm">${x.name}</p>
                    ${statusBadge}
                </div>
                <p class="text-slate-400 mt-1">Size: <span class="text-slate-200">${x.size || '—'}</span> | Unit: <span class="text-slate-200">${x.unit || 'Pcs'}</span> | Available Stock: <span class="${isLow ? 'text-rose-400 font-bold' : 'text-emerald-300 font-bold'} font-mono">${x.stock ?? 0} ${x.unit || 'Pcs'}</span></p>
            </div>
            <div class="flex flex-wrap gap-1.5 items-center justify-end shrink-0 w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800/80">
                <div class="flex items-center gap-1 mr-1">
                    <input id="pkgAdd_${x.id}" type="number" min="0" step="any" placeholder="+Qty" class="w-14 px-2 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500">
                    <button type="button" onclick="addPackageStock('${x.id}',parseFloat(document.getElementById('pkgAdd_${x.id}').value)||0);document.getElementById('pkgAdd_${x.id}').value=''" class="bg-cyan-900/80 hover:bg-cyan-800 text-cyan-200 px-2 py-1.5 rounded-lg border border-cyan-700 text-xs font-semibold">+Stock</button>
                </div>
                <button type="button" onclick="viewPackage('${x.id}')" class="bg-slate-800 hover:bg-slate-700 text-sky-300 px-2.5 py-1.5 rounded-lg border border-slate-700 font-semibold text-xs transition">👁️ View</button>
                <button type="button" onclick="editPackage('${x.id}')" class="bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1.5 rounded-lg border border-slate-700 font-semibold text-xs transition">✏️ Edit</button>
                <button type="button" onclick="deletePackage('${x.id}')" class="bg-slate-800 hover:bg-rose-950/60 text-rose-300 hover:text-rose-200 px-2.5 py-1.5 rounded-lg border border-slate-700 hover:border-rose-800/60 font-semibold text-xs transition">🗑️ Delete</button>
            </div>
        </div>`;
    }).join('') || '<p class="text-xs text-slate-500 text-center py-6">No package items added yet.</p>';
    renderPackageConsolidationReport();
    if (typeof window.checkLowStockAlerts === 'function') window.checkLowStockAlerts();
    if (typeof window.updateDashboard === 'function') window.updateDashboard();
}

export function switchPackageView(view) {
    if (view === 'report') {
        switchPackageActionTab('consolidated');
    } else {
        switchPackageActionTab('view');
    }
}

export function renderPackageConsolidationReport() {
    const rows = sortByNameAsc(state.packages || []).map(p => ({ name: p.name || '', size: p.size || '', stock: Number(p.stock) || 0, unit: p.unit || 'Pcs' }));
    const summary = [['Total Items', rows.length], ['Total Stock', rows.reduce((s, r) => s + r.stock, 0)], ['Low Stock', rows.filter(r => r.stock <= 5).length], ['Units Used', new Set(rows.map(r => r.unit).filter(Boolean)).size]];
    const sh = document.getElementById('packageReportSummary');
    if (sh) sh.innerHTML = summary.map(([l, v]) => `<div class="bg-slate-900 rounded-lg p-3"><div class="text-[10px] text-slate-400">${l}</div><b class="text-sm text-white">${v}</b></div>`).join('');
    const tb = document.getElementById('packageReportTableBody');
    if (tb) tb.innerHTML = rows.length ? rows.map((r, i) => {
        const isLow = r.stock <= 5;
        const statusBadge = isLow
            ? `<span class="bg-rose-950/80 text-rose-300 border border-rose-800/60 px-2 py-0.5 rounded text-[10px] font-bold uppercase whitespace-nowrap">⚠️ LOW STOCK (${r.stock} ${r.unit})</span>`
            : `<span class="bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 px-2 py-0.5 rounded text-[10px] font-bold uppercase whitespace-nowrap">✓ ${r.stock} ${r.unit}</span>`;
        return `<tr class="border-t border-slate-800 hover:bg-slate-900/50 transition">
            <td class="p-2 text-slate-500 font-mono">${i + 1}</td>
            <td class="p-2 text-cyan-300 font-semibold">${r.name || '—'}</td>
            <td class="p-2 text-slate-400">${r.size || '—'}</td>
            <td class="p-2 text-right font-bold font-mono ${isLow ? 'text-rose-300' : 'text-white'}">${r.stock}</td>
            <td class="p-2 text-slate-300">${r.unit}</td>
            <td class="p-2 text-left">${statusBadge}</td>
        </tr>`;
    }).join('') : '<tr><td colspan="6" class="p-5 text-center text-slate-500">No package items found.</td></tr>';
    const um = {};
    rows.forEach(r => um[r.unit] = (um[r.unit] || 0) + r.stock);
    const uh = document.getElementById('packageReportUnitTotals');
    if (uh) uh.innerHTML = Object.entries(um).sort((a, b) => a[0].localeCompare(b[0])).map(([u, t]) => `<div class="flex justify-between bg-slate-900/70 border border-slate-800 rounded-lg px-3 py-2 text-[11px]"><span class="text-slate-400">Total ${u}</span><b class="text-slate-200 font-mono font-bold">${t} ${u}</b></div>`).join('') || '<div class="text-[10px] text-slate-500">No stock data.</div>';
}

export function getProductPackageInfo(product) {
    if (!product) return null;
    const packageId = String(product.packageId || '');
    const pkg = packageId ? state.packages.find(x => String(x.id) === packageId) : null;
    const qty = Number(product.packageQty) || 0;
    return pkg && qty > 0 ? { id: pkg.id, qty, pkg } : null;
}

export function getPackageSellingUnits(item) {
    return Math.max(1, Number(item?.numberOfUnits) || 1);
}

export function resolvePackageInfoForItem(item) {
    if (!item) return null;
    if (item.isPackage) {
        const pkg = state.packages.find(x => String(x.id) === String(item.packageId) || x.name === item.productName);
        if (pkg) return { id: pkg.id, qty: 1, pkg, product: null };
    }
    let product = null;
    const category = String(item.combinedCategory || item.category || 'Cleaning');
    if (item.stockId) {
        product = (category === 'Cosmetics' ? state.cosProducts.find(x => String(x.id) === String(item.stockId)) : state.products.find(x => String(x.id) === String(item.stockId))) || null;
        if (!product) product = state.cosProducts.find(x => String(x.id) === String(item.stockId)) || state.products.find(x => String(x.id) === String(item.stockId)) || null;
    }
    if (!product && item.productName) {
        const nm = String(item.productName).trim().toLowerCase();
        const list = category === 'Cosmetics' ? [...state.cosProducts, ...state.products] : [...state.products, ...state.cosProducts];
        product = list.find(x => String(x.name || '').trim().toLowerCase() === nm) || null;
    }

    let packageId = String(item.packageId || product?.packageId || '');
    let packageQty = Number(item.packageQty) > 0 ? Number(item.packageQty) : Number(product?.packageQty) || 0;
    const packageName = String(item.packageName || product?.packageName || '').trim().toLowerCase();
    let pkg = packageId ? state.packages.find(x => String(x.id) === packageId) : null;
    if (!pkg && packageName) pkg = state.packages.find(x => String(x.name || '').trim().toLowerCase() === packageName) || null;
    if (pkg && packageQty > 0) return { id: pkg.id, qty: packageQty, pkg, product };

    const sellingType = String(item.quantityType || '').trim().toLowerCase();
    if (sellingType) {
        const directPkg = state.packages.find(x => String(x.name || '').trim().toLowerCase() === sellingType);
        if (directPkg) return { id: directPkg.id, qty: 1, pkg: directPkg, product };
    }

    const qty = Number(item.qty) || 0;
    const unitType = String(item.unitType || '').trim().toLowerCase();
    const productName = String(item.productName || product?.name || '').trim().toLowerCase();
    if (!sellingType || !state.packages.length) return null;

    function normUnit(u) {
        u = String(u || '').toLowerCase().trim();
        if (['millilitre', 'millilitres', 'milliliter', 'milliliters', 'ml'].includes(u)) return 'ml';
        if (['litre', 'litres', 'liter', 'liters', 'ltr', 'l'].includes(u)) return 'l';
        if (['kilogram', 'kilograms', 'kilogramme', 'kg'].includes(u)) return 'kg';
        if (['gram', 'grams', 'g'].includes(u)) return 'g';
        return u;
    }
    function extSize(v) {
        const m = String(v || '').toLowerCase().replace(/,/g, '').match(/(\d+(?:\.\d+)?)\s*(ml|millilitres?|l|ltr|litres?|liters?|kg|kilograms?|g|grams?)/i);
        return m ? { n: Number(m[1]), u: normUnit(m[2]) } : null;
    }
    const billSize = { n: qty, u: normUnit(unitType) };
    const typeWord = sellingType === 'bottle' ? 'bottle' : sellingType === 'pack' ? 'pack' : sellingType;

    const candidates = state.packages.map(x => {
        const pu = String(x.unit || 'Pcs').trim().toLowerCase();
        const pn = String(x.name || '').trim().toLowerCase();
        const ps = extSize(x.size);
        const pnSize = extSize(x.name);
        let score = -1;

        const typeOk = sellingType === 'bottle'
            ? (pu === 'bottle' || pu === 'bottles' || pn.includes('bottle'))
            : sellingType === 'pack'
                ? (pu === 'pack' || pu === 'packs' || pn.includes('pack'))
                : (pu === sellingType || pn.includes(typeWord));
        const pcsFallback = (pu === 'pcs' || pu === 'piece' || pu === 'pieces') && (pn.includes(typeWord));
        if (typeOk || pcsFallback) score = 40;
        else return { ...x, score: -1 };

        if (pn === sellingType || pn === typeWord) score += 200;
        if (ps && ps.n === billSize.n && ps.u === billSize.u) score += 300;
        if (pnSize && pnSize.n === billSize.n && pnSize.u === billSize.u) score += 260;
        if (productName && pn.includes(productName)) score += 120;
        const productWords = productName.split(/\s+/).filter(w => w.length >= 3);
        productWords.forEach(w => { if (pn.includes(w)) score += 8; });

        const billSizeText = (qty + ' ' + billSize.u).replace(/\s+/g, '').toLowerCase();
        if (String(x.size || '').toLowerCase().replace(/\s+/g, '').includes(billSizeText)) score += 180;
        if (pn.replace(/\s+/g, '').includes(billSizeText)) score += 160;

        return { ...x, score };
    }).filter(x => x.score > 40).sort((a, b) => b.score - a.score);

    if (!candidates.length) return null;
    const best = candidates[0];
    return { id: best.id, qty: 1, pkg: state.packages.find(x => String(x.id) === String(best.id)) || best, product };
}

export function restorePackageStock(items) {
    (items || []).forEach(item => {
        const info = resolvePackageInfoForItem(item);
        if (info && info.pkg) info.pkg.stock = (Number(info.pkg.stock) || 0) + info.qty * getPackageSellingUnits(item);
    });
}

export function checkAndDeductPackageStock(items) {
    const need = {};
    const missing = [];
    (items || []).forEach(item => {
        const info = resolvePackageInfoForItem(item);
        if (info) {
            need[info.id] = (need[info.id] || 0) + info.qty * getPackageSellingUnits(item);
        } else {
            const hasPackageIntent = item?.packageId || item?.isPackage || (item?.quantityType && item.quantityType !== 'General' && item.quantityType !== 'Other');
            if (hasPackageIntent && state.packages.length > 0) {
                missing.push(item?.productName || 'Unknown Product');
            }
        }
    });
    if (missing.length) {
        return { ok: false, missing: true, products: [...new Set(missing)] };
    }
    for (const id in need) {
        const pkg = state.packages.find(x => String(x.id) === String(id));
        if (!pkg) return { ok: false, missing: true, products: ['Package mapping not found'] };
        if (need[id] > Number(pkg.stock || 0)) return { ok: false, pkg, need: need[id] };
    }
    for (const id in need) {
        const pkg = state.packages.find(x => String(x.id) === String(id));
        if (pkg) pkg.stock = (Number(pkg.stock) || 0) - need[id];
    }
    saveLocalStateSafely();
    return { ok: true, need };
}

export function saveProduct(e) {
    e.preventDefault();
    const id = document.getElementById('prodId').value;
    const name = toTitleCase(document.getElementById('prodName').value.trim());
    const barcode = document.getElementById('prodBarcode').value.trim();
    const stock = parseFloat(document.getElementById('prodStock').value) || 0;
    const unit = document.getElementById('prodUnit').value;
    const wholesalePrice = parseFloat(document.getElementById('prodWholesalePrice').value) || 0;
    const retailPrice = parseFloat(document.getElementById('prodRetailPrice').value) || 0;
    const rawPackageId = document.getElementById('prodPackageId')?.value || '';
    const rawPackageQty = parseFloat(document.getElementById('prodPackageQty')?.value) || 0;
    const selectedText = document.getElementById('prodPackageId')?.selectedOptions?.[0]?.textContent || '';
    const mapped = normalizePackageMapping(rawPackageId, rawPackageQty, selectedText.split(' (Stock:')[0]);
    const packageId = mapped.packageId, packageQty = mapped.packageQty, packageName = mapped.packageName;
    if (rawPackageId && !packageId) { alert('Selected package was not found. Please refresh the package list and select the package again.'); return; }
    const variants = getProductFormVariants('cleaning');
    const finalProdId = id === "" ? ('prod_' + Date.now().toString()) : id;
    unmarkIdDeleted(finalProdId);
    const stamp = Date.now();
    const prodData = { id: finalProdId, name, barcode, stock, unit, wholesalePrice, retailPrice, packageId, packageQty, packageName, variants, savedAt: stamp };
    if (id === "") { state.products.push(prodData); }
    else { const idx = state.products.findIndex(p => String(p.id) === String(id)); if (idx !== -1) state.products[idx] = { ...state.products[idx], ...prodData }; }
    syncToFirebase();
    resetProductForm();
    renderProducts();
    if (typeof updateProductDropdown === 'function') updateProductDropdown();
    if (typeof updateCosProductDropdowns === 'function') updateCosProductDropdowns();
    if (typeof updateCleaningAddStockDropdown === 'function') updateCleaningAddStockDropdown();
    if (typeof window.checkLowStockAlerts === 'function') window.checkLowStockAlerts();
    updateStockReturnDropdowns();
    renderConsolidatedStockReport();
}

export function addCleaningStock() {
    const id = document.getElementById('cleanAddStockProduct')?.value;
    const qty = parseFloat(document.getElementById('cleanAddStockQty')?.value);
    if (!id || !(qty > 0)) { alert('Product and valid stock quantity are required.'); return; }
    const p = state.products.find(x => x.id === id); if (!p) return;
    p.stock = (parseFloat(p.stock) || 0) + qty;
    p.savedAt = Date.now();
    syncToFirebase();
    document.getElementById('cleanAddStockQty').value = ''; renderProducts();
    if (typeof updateProductDropdown === 'function') updateProductDropdown();
    updateCleaningAddStockDropdown();
    updateStockReturnDropdowns();
    renderConsolidatedStockReport();
}

export function updateCleaningAddStockDropdown() {
    const sel = document.getElementById('cleanAddStockProduct');
    if (!sel) return;
    sel.innerHTML = '<option value="">Product</option>';
    sortByNameAsc(state.products).forEach(p => {
        sel.innerHTML += `<option value="${p.id}">${toTitleCase(p.name)} (Current: ${p.stock} ${p.unit})</option>`;
    });
}


// ================= ADVANCED CUSTOMER & BILL-LINKED STOCK RETURN ENGINE =================

export function calculateReturnStockUnits(product, returnQty, packSize, packUnit) {
    if (!product || !(returnQty > 0)) return 0;
    const prodUnit = String(product.unit || 'Ltr').toLowerCase().trim();
    const pSize = parseFloat(packSize) || 0;
    const pUnit = String(packUnit || '').toLowerCase().trim();

    // Volume-based conversion (ml to Ltr)
    if (['ltr', 'l', 'litre'].includes(prodUnit)) {
        if (['ml', 'millilitre'].includes(pUnit) && pSize > 0) {
            return (returnQty * pSize) / 1000;
        }
        if (['ltr', 'l', 'litre'].includes(pUnit) && pSize > 0) {
            return returnQty * pSize;
        }
        if (pSize > 0 && !pUnit) {
            return pSize >= 50 ? (returnQty * pSize) / 1000 : (returnQty * pSize);
        }
    }

    // Weight-based conversion (g to Kg)
    if (['kg', 'kilogram'].includes(prodUnit)) {
        if (['g', 'gm', 'gram'].includes(pUnit) && pSize > 0) {
            return (returnQty * pSize) / 1000;
        }
        if (['kg', 'kilogram'].includes(pUnit) && pSize > 0) {
            return returnQty * pSize;
        }
    }

    // Direct unit match or count-based (Pcs, Bottle, Box, etc.)
    return returnQty;
}

export function toggleStockReturnMode(type, mode) {
    const isCos = type === 'cosmetics';
    const prefix = isCos ? 'cosReturn' : 'cleanReturn';
    const modeInput = document.getElementById(prefix + 'Mode');
    if (modeInput) modeInput.value = mode;

    const billBtn = document.getElementById(prefix + 'ModeBillBtn');
    const directBtn = document.getElementById(prefix + 'ModeDirectBtn');
    const billSec = document.getElementById(prefix + 'BillSection');
    const directSec = document.getElementById(prefix + 'DirectSection');
    const refundWrapper = document.getElementById(prefix + 'RefundActionWrapper');

    if (mode === 'bill') {
        if (billBtn) billBtn.className = isCos 
            ? 'py-2 text-xs font-bold rounded-lg transition bg-pink-700 text-white shadow'
            : 'py-2 text-xs font-bold rounded-lg transition bg-amber-600 text-white shadow';
        if (directBtn) directBtn.className = 'py-2 text-xs font-bold rounded-lg transition text-slate-400 hover:text-slate-200';
        if (billSec) billSec.classList.remove('hidden');
        if (directSec) directSec.classList.add('hidden');
        if (refundWrapper) refundWrapper.classList.remove('hidden');
    } else {
        if (directBtn) directBtn.className = isCos
            ? 'py-2 text-xs font-bold rounded-lg transition bg-pink-700 text-white shadow'
            : 'py-2 text-xs font-bold rounded-lg transition bg-amber-600 text-white shadow';
        if (billBtn) billBtn.className = 'py-2 text-xs font-bold rounded-lg transition text-slate-400 hover:text-slate-200';
        if (billSec) billSec.classList.add('hidden');
        if (directSec) directSec.classList.remove('hidden');
        if (refundWrapper) refundWrapper.classList.add('hidden');
    }
    calculateStockReturnPreview(type);
}

export function updateStockReturnDropdowns() {
    // 1. Cleaning Bills & Direct Products
    const cleanBillSelect = document.getElementById('cleanReturnBillSelect');
    if (cleanBillSelect) {
        cleanBillSelect.innerHTML = '<option value="">-- Choose Customer Bill --</option>';
        const bills = (state.customers || [])
            .filter(c => c && !c._deleted && (c.billNo || (c.items && c.items.length > 0)))
            .slice()
            .reverse();
        bills.slice(0, 100).forEach(b => {
            const billNo = b.billNo || 'CLN';
            const name = b.name || 'Customer';
            const due = Number(b.pendingAmount || 0);
            const total = Number(b.grandTotal || 0);
            cleanBillSelect.innerHTML += `<option value="${b.id || billNo}">[#${billNo}] ${toTitleCase(name)} • ₹${total}${due > 0 ? ` (Due: ₹${due})` : ''}</option>`;
        });
    }

    const cleanDirectProd = document.getElementById('cleanReturnDirectProduct');
    if (cleanDirectProd) {
        cleanDirectProd.innerHTML = '<option value="">-- Select Cleaning Product --</option>';
        sortByNameAsc(state.products).forEach(p => {
            cleanDirectProd.innerHTML += `<option value="${p.id}">${toTitleCase(p.name)} (Stock: ${p.stock} ${p.unit})</option>`;
        });
    }

    // 2. Cosmetics Bills & Direct Products
    const cosBillSelect = document.getElementById('cosReturnBillSelect');
    if (cosBillSelect) {
        cosBillSelect.innerHTML = '<option value="">-- Choose Customer Bill --</option>';
        const cosBills = (state.cosSales || [])
            .filter(b => b && !b._deleted && (b.billNo || (b.items && b.items.length > 0)))
            .slice()
            .reverse();
        cosBills.slice(0, 100).forEach(b => {
            const billNo = b.billNo || 'COS';
            const name = b.customer || b.customerName || b.name || 'Customer';
            const due = Number(b.pendingAmount || 0);
            const total = Number(b.grandTotal || 0);
            cosBillSelect.innerHTML += `<option value="${b.id || billNo}">[#${billNo}] ${toTitleCase(name)} • ₹${total}${due > 0 ? ` (Due: ₹${due})` : ''}</option>`;
        });
    }

    const cosDirectProd = document.getElementById('cosReturnDirectProduct');
    if (cosDirectProd) {
        cosDirectProd.innerHTML = '<option value="">-- Select Cosmetic Product --</option>';
        sortByNameAsc(state.cosProducts).forEach(p => {
            cosDirectProd.innerHTML += `<option value="${p.id}">${toTitleCase(p.name)} (Stock: ${p.stock} ${p.unit})</option>`;
        });
    }
}

export function onStockReturnBillSelected(type) {
    const isCos = type === 'cosmetics';
    const prefix = isCos ? 'cosReturn' : 'cleanReturn';
    const billSelect = document.getElementById(prefix + 'BillSelect');
    const billCard = document.getElementById(prefix + 'BillCard');
    const itemSelect = document.getElementById(prefix + 'ItemSelect');
    const billId = billSelect?.value;

    if (!billId) {
        if (billCard) billCard.classList.add('hidden');
        if (itemSelect) itemSelect.innerHTML = '<option value="">-- Select Bill First --</option>';
        calculateStockReturnPreview(type);
        return;
    }

    const list = isCos ? (state.cosSales || []) : (state.customers || []);
    const bill = list.find(b => String(b.id) === String(billId) || String(b.billNo) === String(billId));

    if (!bill) return;

    // Show Bill Info Card
    if (billCard) {
        billCard.classList.remove('hidden');
        const custNameEl = document.getElementById(prefix + 'BillCustName');
        const billNumEl = document.getElementById(prefix + 'BillNumber');
        const totalEl = document.getElementById(prefix + 'BillTotal');
        const paidEl = document.getElementById(prefix + 'BillPaid');
        const pendingEl = document.getElementById(prefix + 'BillPending');

        if (custNameEl) custNameEl.textContent = toTitleCase(bill.name || bill.customer || 'Customer');
        if (billNumEl) billNumEl.textContent = '#' + (bill.billNo || '—');
        if (totalEl) totalEl.textContent = '₹' + Number(bill.grandTotal || 0).toFixed(2);
        if (paidEl) paidEl.textContent = '₹' + Number(bill.paidAmount || 0).toFixed(2);
        if (pendingEl) pendingEl.textContent = '₹' + Number(bill.pendingAmount || 0).toFixed(2);
    }

    // Populate Item Dropdown
    if (itemSelect) {
        itemSelect.innerHTML = '<option value="">-- Choose Sold Item to Return --</option>';
        const items = Array.isArray(bill.items) ? bill.items : (bill.items && typeof bill.items === 'object' ? Object.values(bill.items) : []);
        items.forEach((it, idx) => {
            const itName = it.productName || it.name || 'Item';
            const itQty = Number(it.qty || it.quantity || 1);
            const itRate = Number(it.rate || it.price || 0);
            const pack = it.packSize || it.size || '';
            const unit = it.unit || 'Bottle';

            const alreadyReturned = (bill.returns || [])
                .filter(r => (r.itemId && r.itemId === it.id) || (r.productName === itName && r.packSize === pack))
                .reduce((s, r) => s + Number(r.qty || 0), 0);
            const remaining = Math.max(0, itQty - alreadyReturned);

            const opt = document.createElement('option');
            opt.value = idx;
            opt.textContent = `${itName} ${pack ? `(${pack})` : ''} — Sold: ${itQty} ${unit} @ ₹${itRate} (Returnable: ${remaining})`;
            if (remaining <= 0) {
                opt.disabled = true;
                opt.textContent += ' [Fully Returned]';
            }
            itemSelect.appendChild(opt);
        });
    }

    calculateStockReturnPreview(type);
}

export function onStockReturnItemSelected(type) {
    const isCos = type === 'cosmetics';
    const prefix = isCos ? 'cosReturn' : 'cleanReturn';
    const billSelect = document.getElementById(prefix + 'BillSelect');
    const itemSelect = document.getElementById(prefix + 'ItemSelect');
    const billId = billSelect?.value;
    const itemIdx = itemSelect?.value;

    if (!billId || itemIdx === '' || itemIdx === undefined) {
        calculateStockReturnPreview(type);
        return;
    }

    const list = isCos ? (state.cosSales || []) : (state.customers || []);
    const bill = list.find(b => String(b.id) === String(billId) || String(b.billNo) === String(billId));
    if (!bill) return;

    const items = Array.isArray(bill.items) ? bill.items : Object.values(bill.items || {});
    const it = items[parseInt(itemIdx, 10)];
    if (!it) return;

    const itQty = Number(it.qty || it.quantity || 1);
    const itRate = Number(it.rate || it.price || 0);

    const itName = it.productName || it.name || '';
    const pack = it.packSize || it.size || '';
    const alreadyReturned = (bill.returns || [])
        .filter(r => (r.itemId && r.itemId === it.id) || (r.productName === itName && r.packSize === pack))
        .reduce((s, r) => s + Number(r.qty || 0), 0);
    const remaining = Math.max(0, itQty - alreadyReturned);

    let packVol = '';
    let packUnit = it.unit || 'Bottle';
    const rawPack = String(pack || it.name || it.productName || '');
    const mlMatch = rawPack.match(/(\d+(?:\.\d+)?)\s*(?:ml|millilitre)/i);
    const ltrMatch = rawPack.match(/(\d+(?:\.\d+)?)\s*(?:ltr|l|litre)/i);
    const gMatch = rawPack.match(/(\d+(?:\.\d+)?)\s*(?:g|gm|gram)/i);
    const kgMatch = rawPack.match(/(\d+(?:\.\d+)?)\s*(?:kg|kilogram)/i);

    if (mlMatch) {
        packVol = mlMatch[1];
        packUnit = 'ml';
    } else if (ltrMatch) {
        packVol = ltrMatch[1];
        packUnit = 'Ltr';
    } else if (gMatch) {
        packVol = gMatch[1];
        packUnit = 'g';
    } else if (kgMatch) {
        packVol = kgMatch[1];
        packUnit = 'Kg';
    } else if (parseFloat(it.size)) {
        packVol = it.size;
    }

    const qtyInput = document.getElementById(prefix + 'Qty');
    const packSizeInput = document.getElementById(prefix + 'PackSize');
    const packUnitSelect = document.getElementById(prefix + 'PackUnit');
    const rateBadge = document.getElementById(prefix + 'ItemRateBadge');

    if (qtyInput) {
        qtyInput.value = remaining > 0 ? (remaining >= 1 ? 1 : remaining) : 0;
        qtyInput.max = remaining;
    }
    if (packSizeInput && packVol) packSizeInput.value = packVol;
    if (packUnitSelect && packUnit) {
        if (![...packUnitSelect.options].some(o => o.value.toLowerCase() === packUnit.toLowerCase())) {
            packUnitSelect.add(new Option(packUnit, packUnit));
        }
        packUnitSelect.value = packUnit;
    }
    if (rateBadge) rateBadge.textContent = `Rate: ₹${itRate.toFixed(2)}`;

    const refundSelect = document.getElementById(prefix + 'RefundAction');
    if (refundSelect) {
        const pending = Number(bill.pendingAmount || 0);
        refundSelect.value = pending > 0 ? 'due' : 'cash';
    }

    calculateStockReturnPreview(type);
}

export function onStockReturnDirectProductSelected(type) {
    calculateStockReturnPreview(type);
}

export function setStockReturnPreset(type, size, unit) {
    const isCos = type === 'cosmetics';
    const prefix = isCos ? 'cosReturn' : 'cleanReturn';
    const sizeInput = document.getElementById(prefix + 'PackSize');
    const unitSelect = document.getElementById(prefix + 'PackUnit');
    if (sizeInput) sizeInput.value = size;
    if (unitSelect) unitSelect.value = unit;
    calculateStockReturnPreview(type);
}

export function calculateStockReturnPreview(type) {
    const isCos = type === 'cosmetics';
    const prefix = isCos ? 'cosReturn' : 'cleanReturn';
    const mode = document.getElementById(prefix + 'Mode')?.value || 'bill';
    const qty = parseFloat(document.getElementById(prefix + 'Qty')?.value) || 0;
    const packSize = parseFloat(document.getElementById(prefix + 'PackSize')?.value) || 0;
    const packUnit = document.getElementById(prefix + 'PackUnit')?.value || 'ml';
    const condition = document.getElementById(prefix + 'Condition')?.value || 'Usable';
    const refundAction = document.getElementById(prefix + 'RefundAction')?.value || 'due';

    const amtPreview = document.getElementById(prefix + 'AmountPreview');
    const stockPreview = document.getElementById(prefix + 'StockPreview');
    const finPreview = document.getElementById(prefix + 'FinancePreview');

    let itemRate = 0;
    let prod = null;
    let bill = null;

    if (mode === 'bill') {
        const billSelect = document.getElementById(prefix + 'BillSelect');
        const itemSelect = document.getElementById(prefix + 'ItemSelect');
        const billId = billSelect?.value;
        const itemIdx = itemSelect?.value;

        if (billId) {
            const list = isCos ? (state.cosSales || []) : (state.customers || []);
            bill = list.find(b => String(b.id) === String(billId) || String(b.billNo) === String(billId));
            if (bill && itemIdx !== '' && itemIdx !== undefined) {
                const items = Array.isArray(bill.items) ? bill.items : Object.values(bill.items || {});
                const it = items[parseInt(itemIdx, 10)];
                if (it) {
                    itemRate = Number(it.rate || it.price || 0);
                    const prodList = isCos ? state.cosProducts : state.products;
                    prod = prodList.find(p => p.id === it.productId || p.name === (it.productName || it.name));
                }
            }
        }
    } else {
        const directProdSelect = document.getElementById(prefix + 'DirectProduct');
        const prodId = directProdSelect?.value;
        const prodList = isCos ? state.cosProducts : state.products;
        prod = prodList.find(p => p.id === prodId);
        if (prod) {
            itemRate = Number(getProductRetailPrice(prod) || 0);
        }
    }

    const returnAmount = qty * itemRate;
    if (amtPreview) amtPreview.textContent = `₹${returnAmount.toFixed(2)}`;

    // Stock impact
    if (stockPreview) {
        if (!prod && mode === 'direct') {
            stockPreview.textContent = 'Stock Impact: Please select a product';
        } else if (condition === 'Damaged') {
            stockPreview.innerHTML = '<span class="text-rose-400 font-bold">🔴 Damaged stock:</span> Will NOT be added to usable inventory.';
        } else {
            const converted = prod ? calculateReturnStockUnits(prod, qty, packSize, packUnit) : qty;
            const u = prod ? prod.unit : (packUnit || 'units');
            stockPreview.innerHTML = `<span class="text-emerald-400 font-bold">🟢 Usable stock:</span> +${Number(converted.toFixed(3))} ${u} will be added back to inventory.`;
        }
    }

    // Financial impact
    if (finPreview) {
        if (mode === 'bill' && bill) {
            const pending = Number(bill.pendingAmount || 0);
            if (refundAction === 'due') {
                const dueDeduct = Math.min(pending, returnAmount);
                const surplus = Math.max(0, returnAmount - pending);
                if (pending <= 0) {
                    finPreview.innerHTML = `⚠️ Bill has ₹0 due. Consider selecting <strong>Cash Refund</strong>.`;
                } else if (surplus > 0) {
                    finPreview.innerHTML = `💳 <strong>Bill Due Reduced:</strong> -₹${dueDeduct.toFixed(2)} (New Due: ₹0) + 💵 <strong>Surplus Cash:</strong> ₹${surplus.toFixed(2)}`;
                } else {
                    finPreview.innerHTML = `💳 <strong>Bill Due Reduced:</strong> -₹${dueDeduct.toFixed(2)} (New Due: ₹${(pending - dueDeduct).toFixed(2)})`;
                }
            } else if (refundAction === 'cash') {
                finPreview.innerHTML = `💵 <strong>Cash Refund:</strong> ₹${returnAmount.toFixed(2)} refunded to customer & recorded in DayBook expense.`;
            } else {
                finPreview.innerHTML = `📦 <strong>Stock Only:</strong> No bill or cash adjustment.`;
            }
        } else if (mode === 'bill') {
            finPreview.textContent = 'Financial Impact: Select a bill to view impact';
        } else {
            finPreview.textContent = 'Direct return: Stock updated, no bill deduction.';
        }
    }
}

export function saveStockReturn(event, type) {
    event.preventDefault();
    const isCos = type === 'cosmetics';
    const prefix = isCos ? 'cosReturn' : 'cleanReturn';
    const mode = document.getElementById(prefix + 'Mode')?.value || 'bill';
    const qty = parseFloat(document.getElementById(prefix + 'Qty')?.value) || 0;
    const packSize = parseFloat(document.getElementById(prefix + 'PackSize')?.value) || 0;
    const packUnit = document.getElementById(prefix + 'PackUnit')?.value || 'ml';
    const condition = document.getElementById(prefix + 'Condition')?.value;
    const reason = (document.getElementById(prefix + 'Reason')?.value || '').trim();
    const remarks = (document.getElementById(prefix + 'Remarks')?.value || '').trim();
    const refundAction = document.getElementById(prefix + 'RefundAction')?.value || 'due';

    if (!(qty > 0)) {
        alert('Please enter a valid return quantity greater than 0.');
        return;
    }
    if (!condition) {
        alert('Please select stock condition (Usable or Damaged).');
        return;
    }

    const prodList = isCos ? state.cosProducts : state.products;
    const billList = isCos ? (state.cosSales || []) : (state.customers || []);

    let product = null;
    let bill = null;
    let selectedItem = null;
    let itemRate = 0;
    let customerName = '';
    let billNo = '';
    let billId = '';
    let returnAmount = 0;
    let convertedStockQty = 0;

    if (mode === 'bill') {
        const billSelect = document.getElementById(prefix + 'BillSelect');
        const itemSelect = document.getElementById(prefix + 'ItemSelect');
        billId = billSelect?.value;
        const itemIdx = itemSelect?.value;

        if (!billId) {
            alert('Please select a customer bill.');
            return;
        }
        if (itemIdx === '' || itemIdx === undefined) {
            alert('Please select the item to return from the chosen bill.');
            return;
        }

        bill = billList.find(b => String(b.id) === String(billId) || String(b.billNo) === String(billId));
        if (!bill) {
            alert('Selected bill not found.');
            return;
        }

        const items = Array.isArray(bill.items) ? bill.items : Object.values(bill.items || {});
        selectedItem = items[parseInt(itemIdx, 10)];
        if (!selectedItem) {
            alert('Selected item not found in bill.');
            return;
        }

        const itName = selectedItem.productName || selectedItem.name || '';
        const pack = selectedItem.packSize || selectedItem.size || '';
        const itQty = Number(selectedItem.qty || selectedItem.quantity || 1);
        const alreadyReturned = (bill.returns || [])
            .filter(r => (r.itemId && r.itemId === selectedItem.id) || (r.productName === itName && r.packSize === pack))
            .reduce((s, r) => s + Number(r.qty || 0), 0);
        const remaining = Math.max(0, itQty - alreadyReturned);

        if (qty > remaining + 0.001) {
            alert(`Return quantity (${qty}) exceeds remaining returnable quantity (${remaining}) for this item.`);
            return;
        }

        customerName = bill.name || bill.customer || 'Customer';
        billNo = bill.billNo || '';
        itemRate = Number(selectedItem.rate || selectedItem.price || 0);
        returnAmount = Math.round((qty * itemRate) * 100) / 100;

        product = prodList.find(p => p.id === selectedItem.productId || p.name === itName);

        if (refundAction === 'due') {
            const currentPending = Number(bill.pendingAmount || 0);
            const dueDeduction = Math.min(currentPending, returnAmount);
            bill.pendingAmount = Math.max(0, currentPending - dueDeduction);
            const surplusCash = Math.max(0, returnAmount - dueDeduction);

            if (surplusCash > 0) {
                if (!Array.isArray(state.expenses)) state.expenses = [];
                state.expenses.push({
                    id: generateUniqueRecordId('exp'),
                    type: 'Expense',
                    category: 'Sales Return Refund',
                    title: `Sales Return Refund (Surplus) - ${customerName} (Bill #${billNo})`,
                    amount: surplusCash,
                    date: todayDDMMYYYY(),
                    paymentMode: 'Cash',
                    savedAt: Date.now()
                });
            }
        } else if (refundAction === 'cash') {
            if (!Array.isArray(state.expenses)) state.expenses = [];
            state.expenses.push({
                id: generateUniqueRecordId('exp'),
                type: 'Expense',
                category: 'Sales Return Refund',
                title: `Sales Return Refund - ${customerName} (Bill #${billNo})`,
                amount: returnAmount,
                date: todayDDMMYYYY(),
                paymentMode: 'Cash',
                savedAt: Date.now()
            });
        }

        bill.returnedAmount = (Number(bill.returnedAmount || 0)) + returnAmount;
        if (!Array.isArray(bill.returns)) bill.returns = [];
        const returnId = 'ret_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
        bill.returns.push({
            id: returnId,
            itemId: selectedItem.id || '',
            productId: product ? product.id : (selectedItem.productId || ''),
            productName: itName,
            packSize: packSize ? `${packSize} ${packUnit}` : (pack || ''),
            qty,
            rate: itemRate,
            returnAmount,
            condition,
            refundType: refundAction,
            reason,
            remarks,
            date: todayDDMMYYYY(),
            savedAt: Date.now()
        });
        bill.savedAt = Date.now();

    } else {
        const directProdSelect = document.getElementById(prefix + 'DirectProduct');
        const prodId = directProdSelect?.value;
        product = prodList.find(p => p.id === prodId);
        if (!product) {
            alert('Please select a product for direct return.');
            return;
        }
        customerName = (document.getElementById(prefix + 'DirectCustomer')?.value || '').trim() || 'Direct Return';
        itemRate = Number(getProductRetailPrice(product) || 0);
        returnAmount = Math.round((qty * itemRate) * 100) / 100;
    }

    // Replenish usable stock
    if (condition === 'Usable') {
        if (product) {
            convertedStockQty = calculateReturnStockUnits(product, qty, packSize, packUnit);
            product.stock = Math.round(((parseFloat(product.stock) || 0) + convertedStockQty) * 1000) / 1000;
            product.savedAt = Date.now();
        }
    }

    if (!Array.isArray(state.stockReturns)) state.stockReturns = [];
    const returnRecord = {
        id: 'ret_' + Date.now().toString() + '_' + Math.random().toString(36).slice(2, 7),
        type,
        mode,
        billId: bill ? (bill.id || '') : '',
        billNo: bill ? (bill.billNo || '') : '',
        productId: product ? product.id : (selectedItem ? selectedItem.productId : ''),
        productName: product ? product.name : (selectedItem ? (selectedItem.productName || selectedItem.name) : 'Product'),
        packSize: packSize ? `${packSize} ${packUnit}` : (selectedItem ? selectedItem.packSize : ''),
        unit: product ? product.unit : packUnit,
        qty,
        convertedBaseQty: condition === 'Usable' ? convertedStockQty : 0,
        rate: itemRate,
        returnAmount,
        refundType: mode === 'bill' ? refundAction : 'none',
        customer: customerName,
        condition,
        reason,
        remarks,
        date: todayDDMMYYYY(),
        savedAt: Date.now()
    };
    state.stockReturns.push(returnRecord);

    saveLocalStateSafely();
    syncToFirebase();

    const form = document.getElementById(prefix + 'StockForm');
    if (form) form.reset();
    const billCard = document.getElementById(prefix + 'BillCard');
    if (billCard) billCard.classList.add('hidden');
    const itemSelect = document.getElementById(prefix + 'ItemSelect');
    if (itemSelect) itemSelect.innerHTML = '<option value="">-- Choose Customer Bill First --</option>';

    renderProducts();
    renderCosProductStock();
    if (typeof updateProductDropdown === 'function') updateProductDropdown();
    updateCosProductDropdowns();
    if (typeof updateCleaningAddStockDropdown === 'function') updateCleaningAddStockDropdown();
    updateStockReturnDropdowns();
    renderStockReturnHistory();
    renderConsolidatedStockReport();
    if (window.renderCustomers) window.renderCustomers();
    if (window.renderCosSales) window.renderCosSales();
    if (window.renderSalesHistory) window.renderSalesHistory();
    if (window.renderDayBook) window.renderDayBook();
    if (window.updateDashboard) window.updateDashboard();

    const actionText = refundAction === 'due' ? 'Deducted from Pending Due' : refundAction === 'cash' ? 'Cash Refund Recorded' : 'Stock Adjustment Only';
    const alertMsg = condition === 'Usable'
        ? `✅ Return Saved Successfully!\n\n• Product: ${returnRecord.productName} (${returnRecord.packSize || ''})\n• Returned: ${qty} (+${convertedStockQty} ${product ? product.unit : ''} to Stock)\n• Value: ₹${returnAmount.toFixed(2)}${mode === 'bill' ? `\n• Customer Bill: #${billNo} (${actionText})` : ''}`
        : `⚠️ Return Recorded as Damaged!\n\n• Product: ${returnRecord.productName}\n• Qty: ${qty}\n• Stock was NOT added to usable inventory.\n• Value: ₹${returnAmount.toFixed(2)}${mode === 'bill' ? `\n• Customer Bill: #${billNo} (${actionText})` : ''}`;

    alert(alertMsg);
}

export function renderStockReturnHistory() {
    const clean = document.getElementById('cleanReturnHistoryContainer');
    const cos = document.getElementById('cosReturnHistoryContainer');
    const render = (container, type) => {
        if (!container) return;
        const rows = (state.stockReturns || []).filter(r => r.type === type).slice().reverse();
        if (!rows.length) {
            container.innerHTML = '<p class="text-[10px] text-slate-500 text-center py-2">No return records yet.</p>';
            return;
        }
        container.innerHTML = rows.slice(0, 30).map(r => {
            const isUsable = r.condition === 'Usable';
            const condBadge = isUsable 
                ? '<span class="text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded-md border border-emerald-800">🟢 Usable (+Stock)</span>'
                : '<span class="text-rose-400 font-bold bg-rose-950/80 px-2 py-0.5 rounded-md border border-rose-800">🔴 Damaged</span>';
            const finBadge = r.refundType === 'due'
                ? '<span class="text-amber-300 font-bold bg-amber-950/80 px-2 py-0.5 rounded-md border border-amber-800">💳 Due Deducted</span>'
                : r.refundType === 'cash'
                ? '<span class="text-sky-300 font-bold bg-sky-950/80 px-2 py-0.5 rounded-md border border-sky-800">💵 Cash Refund</span>'
                : '';
            const billBadge = r.billNo ? `<span class="text-amber-400 font-mono font-bold bg-slate-900 px-1.5 py-0.5 rounded border border-slate-700">#${r.billNo}</span>` : '';

            return `
            <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-3 text-xs space-y-1.5 shadow-sm">
                <div class="flex justify-between items-start gap-2">
                    <div>
                        <div class="font-bold text-slate-100 flex items-center gap-1.5 flex-wrap">
                            <span>${r.productName}</span>
                            ${r.packSize ? `<span class="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded font-mono">📦 ${r.packSize}</span>` : ''}
                            ${billBadge}
                        </div>
                        <div class="text-[11px] text-slate-400 mt-0.5">
                            Customer: <strong class="text-slate-200">${r.customer || 'Walk-in'}</strong> • ${r.date}
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="text-amber-300 font-mono font-bold">₹${Number(r.returnAmount || 0).toFixed(2)}</div>
                        <div class="text-[10px] text-slate-500">${r.qty} returned</div>
                    </div>
                </div>
                <div class="flex items-center gap-1.5 flex-wrap pt-1 border-t border-slate-800/80 text-[10px]">
                    ${condBadge}
                    ${finBadge}
                    ${r.convertedBaseQty > 0 ? `<span class="text-slate-400">+${r.convertedBaseQty} ${r.unit} in stock</span>` : ''}
                </div>
                ${r.reason ? `<div class="text-[10px] text-slate-400 italic">Reason: ${r.reason}</div>` : ''}
                ${r.remarks ? `<div class="text-[10px] text-slate-500">Remarks: ${r.remarks}</div>` : ''}
            </div>`;
        }).join('');
    };
    render(clean, 'cleaning');
    render(cos, 'cosmetics');
}

export function renderProducts() {
    const container = document.getElementById('productListContainer');
    if (!container) return;
    container.innerHTML = state.products.length === 0 ? '<p class="text-xs text-slate-500 text-center py-2">No products added yet.</p>' : '';
    sortByNameAsc(state.products).forEach((p) => {
        const variantsBadgeHtml = (p.variants && p.variants.length > 0)
            ? `<div class="flex flex-wrap gap-1 mt-1.5">${p.variants.map(v => `<span class="bg-slate-900 border border-slate-700 text-[10px] px-2 py-0.5 rounded-md text-cyan-300 font-semibold">📦 ${v.name}: ₹${v.retailPrice}</span>`).join('')}</div>`
            : '';
        const wPrice = getProductWholesalePrice(p);
        const rPrice = getProductRetailPrice(p);
        const hasCustomWholesale = (p.wholesalePrice !== undefined && p.wholesalePrice !== null && p.wholesalePrice !== '' && !isNaN(Number(p.wholesalePrice)));
        const wBadge = hasCustomWholesale
            ? `<span class="text-sky-300 font-semibold">W: ₹${Number(p.wholesalePrice).toFixed(2)}</span>`
            : `<span class="text-slate-400 italic text-[10px]" title="Wholesale rate not explicitly set, defaulting to Retail rate">W: ₹${wPrice.toFixed(2)}</span>`;
        const rBadge = `<span class="text-emerald-400 font-semibold">R: ₹${rPrice.toFixed(2)}</span>`;
        container.innerHTML += `
            <div class="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2.5 text-xs">
                <div class="min-w-0 flex-1">
                    <p class="font-bold text-slate-100 text-sm block leading-snug break-words">${p.name} ${p.barcode ? '<span class="text-[10px] text-slate-400 font-normal">[' + p.barcode + ']</span>' : ''}</p>
                    <p class="text-slate-400 mt-1">Stock: <span class="${p.stock <= 5 ? 'text-rose-400 font-bold' : 'text-slate-200 font-semibold'}">${p.stock} ${p.unit}</span> | ${wBadge} | ${rBadge}</p>
                    ${variantsBadgeHtml}
                </div>
                <div class="flex items-center gap-1.5 justify-end shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800/80 w-full sm:w-auto">
                    <button type="button" onclick="viewProduct('${p.id}')" class="flex-1 sm:flex-initial bg-slate-800 hover:bg-slate-700 text-sky-300 px-3 py-1.5 rounded-lg border border-slate-700 font-semibold text-center transition">View</button>
                    <button type="button" onclick="editProduct('${p.id}')" class="flex-1 sm:flex-initial bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 font-semibold text-center transition">Edit</button>
                    <button type="button" onclick="deleteProduct('${p.id}')" class="flex-1 sm:flex-initial bg-slate-800 hover:bg-rose-950/60 text-rose-300 hover:text-rose-200 px-3 py-1.5 rounded-lg border border-slate-700 hover:border-rose-800/60 font-semibold text-center transition">Delete</button>
                </div>
            </div>`;
    });
    if (typeof window.checkLowStockAlerts === 'function') window.checkLowStockAlerts();
}

export function editProduct(id) {
    const p = state.products.find(item => item.id === id);
    if (p) {
        if (typeof window.switchTab === 'function') window.switchTab('stock', false);
        if (typeof window.switchStockSubTab === 'function') window.switchStockSubTab('cleaning');
        if (typeof window.switchStockActionTab === 'function') window.switchStockActionTab('cleaning', 'add');
        document.getElementById('prodId').value = p.id;
        document.getElementById('prodName').value = p.name || '';
        document.getElementById('prodBarcode').value = p.barcode || '';
        document.getElementById('prodStock').value = p.stock ?? 0;
        document.getElementById('prodUnit').value = p.unit || '';
        const wp = (p.wholesalePrice !== undefined && p.wholesalePrice !== null && p.wholesalePrice !== '') ? p.wholesalePrice : (p.costPrice || p.price1 || '');
        const rp = (p.retailPrice !== undefined && p.retailPrice !== null && p.retailPrice !== '') ? p.retailPrice : (p.salePrice || p.price || '');
        document.getElementById('prodWholesalePrice').value = wp !== '' ? wp : '';
        document.getElementById('prodRetailPrice').value = rp !== '' ? rp : '';
        updatePackageSelectors();
        document.getElementById('prodPackageId').value = p.packageId || '';
        document.getElementById('prodPackageQty').value = p.packageQty ?? 1;
        renderProductVariants(p.variants || [], 'cleaning');
        document.getElementById('stockFormTitle').innerText = "Edit Product";
        document.getElementById('prodSubmitBtn').innerText = "Update Product";
        setTimeout(() => document.getElementById('stockFormTitle')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50);
    }
}

export function deleteProduct(id) {
    if (!id) return;
    const p = state.products.find(x => String(x.id) === String(id));
    const name = p ? p.name : 'product';
    if (confirm(`Are you sure you want to delete "${name}"?`)) {
        if (p) markRecordDeleted(p, 'product');
        markIdDeleted(id);
        state.products = state.products.filter(p => String(p.id) !== String(id));
        saveLocalStateSafely();
        syncToFirebase();
        renderProducts();
        renderConsolidatedStockReport();
        if (typeof window.renderAll === 'function') window.renderAll();
    }
}

export function resetProductForm() {
    document.getElementById('productForm').reset();
    document.getElementById('prodId').value = "";
    document.getElementById('stockFormTitle').innerText = "Add New Product";
    document.getElementById('prodSubmitBtn').innerText = "Add Product";
    if (document.getElementById('prodPackageId')) document.getElementById('prodPackageId').value = '';
    if (document.getElementById('prodPackageQty')) document.getElementById('prodPackageQty').value = '1';
    clearProductVariants('cleaning');
}

export function saveCosProduct(e) {
    e.preventDefault();
    const id = document.getElementById('cosProdId').value;
    const name = toTitleCase(document.getElementById('cosProdName').value.trim());
    const barcode = document.getElementById('cosProdBarcode').value.trim();
    const stock = parseFloat(document.getElementById('cosProdStock').value) || 0;
    const unit = document.getElementById('cosProdUnit').value;
    const costPrice = parseFloat(document.getElementById('cosProdCostPrice').value) || 0;
    const salePrice = parseFloat(document.getElementById('cosProdSalePrice').value) || 0;
    const rawPackageId = document.getElementById('cosProdPackageId')?.value || '';
    const rawPackageQty = parseFloat(document.getElementById('cosProdPackageQty')?.value) || 0;
    const selectedText = document.getElementById('cosProdPackageId')?.selectedOptions?.[0]?.textContent || '';
    const mapped = normalizePackageMapping(rawPackageId, rawPackageQty, selectedText.split(' (Stock:')[0]);
    const packageId = mapped.packageId, packageQty = mapped.packageQty, packageName = mapped.packageName;

    if (!name || !unit) return;
    if (rawPackageId && !packageId) { alert('Selected package was not found. Please refresh the package list and select the package again.'); return; }
    const variants = getProductFormVariants('cosmetics');
    const finalCosId = id === '' ? ('cp_' + Date.now().toString()) : id;
    unmarkIdDeleted(finalCosId);
    const stamp = Date.now();
    const cosData = {
        id: finalCosId,
        name, barcode, stock, unit, costPrice, salePrice,
        wholesalePrice: costPrice, retailPrice: salePrice,
        packageId, packageQty, packageName, variants,
        savedAt: stamp
    };
    if (id === '') {
        state.cosProducts.push(cosData);
    } else {
        const idx = state.cosProducts.findIndex(p => p.id === id);
        if (idx !== -1) {
            state.cosProducts[idx] = { ...state.cosProducts[idx], ...cosData };
        }
    }
    syncToFirebase();
    resetCosProductForm();
    renderCosProductStock();
    updateCosProductDropdowns();
    if (typeof updateCleaningAddStockDropdown === 'function') updateCleaningAddStockDropdown();
    updateStockReturnDropdowns();
    renderConsolidatedStockReport();
}

export function addCosmeticStock() {
    const id = document.getElementById('cosAddStockProduct').value;
    const qty = parseFloat(document.getElementById('cosAddStockQty').value);
    if (!id || !(qty > 0)) {
        alert('Product and valid stock quantity are required.');
        return;
    }
    const p = state.cosProducts.find(x => x.id === id);
    if (!p) return;
    p.stock = (parseFloat(p.stock) || 0) + qty;
    p.savedAt = Date.now();
    syncToFirebase();
    document.getElementById('cosAddStockQty').value = '';
    renderCosProductStock();
    updateCosProductDropdowns();
    updateStockReturnDropdowns();
    renderConsolidatedStockReport();
}

export function editCosProduct(id) {
    const p = state.cosProducts.find(x => x.id === id);
    if (!p) return;
    if (typeof window.switchTab === 'function') window.switchTab('stock', false);
    if (typeof window.switchStockSubTab === 'function') window.switchStockSubTab('cosmetics');
    if (typeof window.switchStockActionTab === 'function') window.switchStockActionTab('cosmetics', 'add');
    document.getElementById('cosProdId').value = p.id;
    document.getElementById('cosProdName').value = p.name || '';
    document.getElementById('cosProdBarcode').value = p.barcode || '';
    document.getElementById('cosProdStock').value = p.stock ?? 0;
    document.getElementById('cosProdUnit').value = p.unit || '';
    const wp = (p.wholesalePrice !== undefined && p.wholesalePrice !== null && p.wholesalePrice !== '') ? p.wholesalePrice : (p.costPrice ?? '');
    const rp = (p.retailPrice !== undefined && p.retailPrice !== null && p.retailPrice !== '') ? p.retailPrice : (p.salePrice ?? '');
    document.getElementById('cosProdCostPrice').value = wp;
    document.getElementById('cosProdSalePrice').value = rp;
    updatePackageSelectors();
    document.getElementById('cosProdPackageId').value = p.packageId || '';
    document.getElementById('cosProdPackageQty').value = p.packageQty ?? 1;
    renderProductVariants(p.variants || [], 'cosmetics');
    document.getElementById('cosStockFormTitle').innerText = 'Edit Cosmetic Product';
    document.getElementById('cosProdSubmitBtn').innerText = 'Update Product';
    setTimeout(() => document.getElementById('cosStockFormTitle')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50);
}

export function deleteCosProduct(id) {
    if (!id) return;
    const p = state.cosProducts.find(x => String(x.id) === String(id));
    const name = p ? p.name : 'product';
    if (!confirm(`Delete "${name}" from cosmetic product stock?`)) return;
    if (p) markRecordDeleted(p, 'cosProduct');
    markIdDeleted(id);
    state.cosProducts = state.cosProducts.filter(x => String(x.id) !== String(id));
    saveLocalStateSafely();
    syncToFirebase();
    renderCosProductStock();
    renderConsolidatedStockReport();
    if (typeof window.renderAll === 'function') window.renderAll();
}

export function renderCosProductStock() {
    const container = document.getElementById('cosProductListContainer');
    if (!container) return;

    if (state.cosProducts.length === 0) {
        container.innerHTML = '<p class="text-xs text-slate-500 text-center py-3">No cosmetic products added yet.</p>';
        return;
    }

    container.innerHTML = sortByNameAsc(state.cosProducts).map(p => {
        const variantsBadgeHtml = (p.variants && p.variants.length > 0)
            ? `<div class="flex flex-wrap gap-1 mt-1.5">${p.variants.map(v => `<span class="bg-slate-900 border border-slate-700 text-[10px] px-2 py-0.5 rounded-md text-pink-300 font-semibold">📦 ${v.name}: ₹${v.retailPrice}</span>`).join('')}</div>`
            : '';
        return `
        <div class="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2.5 text-xs">
            <div class="min-w-0 flex-1">
                <div class="flex items-center gap-1.5 flex-wrap">
                    <strong class="text-slate-100 font-bold text-sm block leading-snug break-words">${p.name}</strong>
                    <span class="text-[10px] text-pink-300 bg-pink-950/40 border border-pink-800/40 px-1.5 py-0.5 rounded font-semibold">💄 Cosmetics</span>
                    ${p.barcode ? '<span class="text-[10px] text-slate-400 font-normal">[' + p.barcode + ']</span>' : ''}
                </div>
                <p class="text-slate-400 mt-1">Stock:
                    <span class="${(parseFloat(p.stock) || 0) <= 5 ? 'text-rose-400 font-bold' : 'text-slate-200 font-semibold'}">${p.stock} ${p.unit}</span>
                    | <span class="text-sky-300 font-semibold">W: ₹${getProductWholesalePrice(p).toFixed(2)}</span>
                    | <span class="text-emerald-400 font-semibold">R: ₹${getProductRetailPrice(p).toFixed(2)}</span>
                </p>
                ${variantsBadgeHtml}
            </div>
            <div class="flex items-center gap-1.5 justify-end shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800/80 w-full sm:w-auto">
                <button type="button" onclick="viewCosProduct('${p.id}')" class="flex-1 sm:flex-initial bg-slate-800 hover:bg-slate-700 text-sky-300 px-3 py-1.5 rounded-lg border border-slate-700 font-semibold text-center transition">View</button>
                <button type="button" onclick="editCosProduct('${p.id}')" class="flex-1 sm:flex-initial bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 font-semibold text-center transition">Edit</button>
                <button type="button" onclick="deleteCosProduct('${p.id}')" class="flex-1 sm:flex-initial bg-slate-800 hover:bg-rose-950/60 text-rose-300 hover:text-rose-200 px-3 py-1.5 rounded-lg border border-slate-700 hover:border-rose-800/60 font-semibold text-center transition">Delete</button>
            </div>
        </div>`;
    }).join('');
}

export function resetCosProductForm() {
    const form = document.getElementById('cosProductForm');
    if (form) form.reset();
    document.getElementById('cosProdId').value = '';
    document.getElementById('cosStockFormTitle').innerText = 'Add Cosmetic Product';
    document.getElementById('cosProdSubmitBtn').innerText = 'Add Product';
    if (document.getElementById('cosProdPackageId')) document.getElementById('cosProdPackageId').value = '';
    if (document.getElementById('cosProdPackageQty')) document.getElementById('cosProdPackageQty').value = '1';
    clearProductVariants('cosmetics');
}

export function showCosmeticStockList() {
    renderCosProductStock();
}

export function updateCosProductDropdowns() {
    const pSelect = document.getElementById('cosPurchaseStockSelect');
    const sSelect = document.getElementById('cosSalesStockSelect');
    const addSelect = document.getElementById('cosAddStockProduct');

    if (pSelect) {
        pSelect.innerHTML = '<option value="">-- Select Product --</option>';
        sortByNameAsc(state.cosProducts).forEach(p => {
            pSelect.innerHTML += `<option value="${p.id}" data-price="${p.costPrice}" data-saleprice="${p.salePrice}" data-unit="${p.unit}" data-stock="${p.stock}" data-barcode="${p.barcode || ''}">${p.name} (Stock: ${p.stock} ${p.unit})</option>`;
        });
    }
    if (sSelect) {
        sSelect.innerHTML = '<option value="">-- Select Product --</option>';
        sortByNameAsc(state.cosProducts).forEach(p => {
            sSelect.innerHTML += `<option value="${p.id}" data-price="${p.salePrice}" data-unit="${p.unit}" data-stock="${p.stock}" data-barcode="${p.barcode || ''}">${p.name} (Stock: ${p.stock} ${p.unit})</option>`;
        });
    }
    if (addSelect) {
        addSelect.innerHTML = '<option value="">Product</option>';
        sortByNameAsc(state.cosProducts).forEach(p => {
            addSelect.innerHTML += `<option value="${p.id}">${p.name} (Current: ${p.stock} ${p.unit})</option>`;
        });
    }
}

let currentConsolidatedCategory = 'all';
let currentConsolidatedSearch = '';

export function setConsolidatedStockCategory(cat) {
    currentConsolidatedCategory = cat;
    renderConsolidatedStockReport();
}

export function onConsolidatedStockSearch(val) {
    currentConsolidatedSearch = (val || '').trim().toLowerCase();
    const s1 = document.getElementById('consolidatedStockSearchInput');
    const s2 = document.getElementById('consolidatedStockSearchInputCos');
    if (s1 && s1.value !== val) s1.value = val;
    if (s2 && s2.value !== val) s2.value = val;
    renderConsolidatedStockReport();
}

export function shareConsolidatedStockWhatsApp() {
    const cleaning = Array.isArray(state.products) ? state.products : [];
    const cosmetics = Array.isArray(state.cosProducts) ? state.cosProducts : [];

    let cleanWVal = 0, cleanRVal = 0;
    cleaning.forEach(p => {
        const wPrice = getProductWholesalePrice(p);
        const rPrice = getProductRetailPrice(p);
        const stock = Number(p.stock) || 0;
        cleanWVal += stock * (wPrice > 0 ? wPrice : rPrice);
        cleanRVal += stock * (rPrice > 0 ? rPrice : wPrice);
    });

    let cosWVal = 0, cosRVal = 0;
    cosmetics.forEach(p => {
        const wPrice = getProductWholesalePrice(p);
        const rPrice = getProductRetailPrice(p);
        const stock = Number(p.stock) || 0;
        cosWVal += stock * (wPrice > 0 ? wPrice : rPrice);
        cosRVal += stock * (rPrice > 0 ? rPrice : wPrice);
    });

    const totalWVal = cleanWVal + cosWVal;
    const totalRVal = cleanRVal + cosRVal;

    let msg = `*FIA CLEAN & CARE - PRODUCT CONSOLIDATED STOCK REPORT*\n`;
    msg += `📅 _Date: ${todayDDMMYYYY()}_\n\n`;

    msg += `📊 *PRODUCT SUMMARY:*\n`;
    msg += `• Total Products: ${cleaning.length + cosmetics.length}\n`;
    msg += `• Cleaning Products: ${cleaning.length}\n`;
    msg += `• Cosmetic Products: ${cosmetics.length}\n`;
    msg += `💰 *TOTAL PRODUCT VALUE (Wholesale):* ₹${totalWVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
    msg += `🏷️ *Total Potential Retail Value:* ₹${totalRVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
    msg += `   └ Cleaning Stock Value: ₹${cleanWVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
    msg += `   └ Cosmetics Stock Value: ₹${cosWVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n\n`;

    if (cleaning.length > 0) {
        msg += `🧹 *CLEANING PRODUCTS:*\n`;
        sortByNameAsc(cleaning).forEach((p, idx) => {
            const wPrice = getProductWholesalePrice(p);
            const rPrice = getProductRetailPrice(p);
            const stock = Number(p.stock) || 0;
            const val = stock * (wPrice > 0 ? wPrice : rPrice);
            msg += `${idx + 1}. *${p.name}* - ${stock} ${p.unit} (W: ₹${wPrice} | R: ₹${rPrice}) • *Value: ₹${val.toFixed(2)}*\n`;
        });
        msg += `\n`;
    }

    if (cosmetics.length > 0) {
        msg += `💄 *COSMETIC PRODUCTS:*\n`;
        sortByNameAsc(cosmetics).forEach((p, idx) => {
            const wPrice = getProductWholesalePrice(p);
            const rPrice = getProductRetailPrice(p);
            const stock = Number(p.stock) || 0;
            const val = stock * (wPrice > 0 ? wPrice : rPrice);
            msg += `${idx + 1}. *${p.name}* - ${stock} ${p.unit} (W: ₹${wPrice} | R: ₹${rPrice}) • *Value: ₹${val.toFixed(2)}*\n`;
        });
        msg += `\n`;
    }

    const unitMap = {};
    [...cleaning, ...cosmetics].forEach(p => {
        const u = p.unit || 'No Unit';
        unitMap[u] = (unitMap[u] || 0) + (Number(p.stock) || 0);
    });

    msg += `📦 *STOCK BY UNIT:*\n`;
    Object.entries(unitMap).sort((a, b) => a[0].localeCompare(b[0])).forEach(([u, total]) => {
        msg += `• Total ${u}: ${Number(total.toFixed(2))} ${u}\n`;
    });

    const url = 'https://wa.me/?text=' + encodeURIComponent(msg);
    window.open(url, '_blank');
}

export function renderConsolidatedStockReport() {
    const cleaning = Array.isArray(state.products) ? state.products : [];
    const cosmetics = Array.isArray(state.cosProducts) ? state.cosProducts : [];

    const allRows = [
        ...cleaning.map(p => {
            const wPrice = getProductWholesalePrice(p);
            const rPrice = getProductRetailPrice(p);
            const stock = Number(p.stock) || 0;
            const wholesaleValuation = stock * (wPrice > 0 ? wPrice : rPrice);
            const retailValuation = stock * (rPrice > 0 ? rPrice : wPrice);
            return {
                id: p.id,
                category: 'Cleaning',
                name: p.name || '',
                stock: stock,
                unit: p.unit || 'Ltr',
                barcode: p.barcode || '',
                wholesalePrice: wPrice,
                retailPrice: rPrice,
                packageName: p.packageName || '',
                packageQty: Number(p.packageQty) || 1,
                variants: Array.isArray(p.variants) ? p.variants : [],
                wholesaleValuation: wholesaleValuation,
                retailValuation: retailValuation,
                isLowStock: stock <= 5
            };
        }),
        ...cosmetics.map(p => {
            const wPrice = getProductWholesalePrice(p);
            const rPrice = getProductRetailPrice(p);
            const stock = Number(p.stock) || 0;
            const wholesaleValuation = stock * (wPrice > 0 ? wPrice : rPrice);
            const retailValuation = stock * (rPrice > 0 ? rPrice : wPrice);
            return {
                id: p.id,
                category: 'Cosmetics',
                name: p.name || '',
                stock: stock,
                unit: p.unit || 'Pcs',
                barcode: p.barcode || '',
                wholesalePrice: wPrice,
                retailPrice: rPrice,
                packageName: p.packageName || '',
                packageQty: Number(p.packageQty) || 1,
                variants: Array.isArray(p.variants) ? p.variants : [],
                wholesaleValuation: wholesaleValuation,
                retailValuation: retailValuation,
                isLowStock: stock <= 5
            };
        })
    ];

    // Filter by Category (Cleaning or Cosmetics only)
    let filteredRows = allRows;
    if (currentConsolidatedCategory === 'cleaning') {
        filteredRows = allRows.filter(r => r.category === 'Cleaning');
    } else if (currentConsolidatedCategory === 'cosmetics') {
        filteredRows = allRows.filter(r => r.category === 'Cosmetics');
    }

    // Filter by Search Query
    if (currentConsolidatedSearch) {
        const q = currentConsolidatedSearch.toLowerCase();
        filteredRows = filteredRows.filter(r => {
            const variantText = (r.variants || []).map(v => `${v.name || ''} ${v.size || ''} ${v.packageName || ''}`).join(' ').toLowerCase();
            return (
                (r.name || '').toLowerCase().includes(q) ||
                (r.barcode || '').toLowerCase().includes(q) ||
                (r.category || '').toLowerCase().includes(q) ||
                (r.unit || '').toLowerCase().includes(q) ||
                (r.packageName || '').toLowerCase().includes(q) ||
                variantText.includes(q)
            );
        });
    }

    // Sort: Category first (Cleaning -> Cosmetics), then Name Ascending
    filteredRows.sort((a, b) => {
        const catOrder = { 'Cleaning': 1, 'Cosmetics': 2 };
        const orderDiff = (catOrder[a.category] || 9) - (catOrder[b.category] || 9);
        if (orderDiff !== 0) return orderDiff;
        return String(a.name).localeCompare(String(b.name));
    });

    const cleanInStock = cleaning.filter(p => (Number(p.stock) || 0) > 0).length;
    const cleanOutOfStock = cleaning.length - cleanInStock;
    const cosInStock = cosmetics.filter(p => (Number(p.stock) || 0) > 0).length;
    const cosOutOfStock = cosmetics.length - cosInStock;

    const cleanWVal = cleaning.reduce((sum, p) => {
        const w = getProductWholesalePrice(p);
        const r = getProductRetailPrice(p);
        return sum + (Number(p.stock) || 0) * (w > 0 ? w : r);
    }, 0);
    const cosWVal = cosmetics.reduce((sum, p) => {
        const w = getProductWholesalePrice(p);
        const r = getProductRetailPrice(p);
        return sum + (Number(p.stock) || 0) * (w > 0 ? w : r);
    }, 0);

    const totalWholesaleVal = cleanWVal + cosWVal;
    const totalRetailVal = allRows.reduce((sum, r) => sum + (r.retailValuation || 0), 0);
    const lowStockCount = allRows.filter(r => r.isLowStock).length;

    const summaryCards = [
        { label: 'Total Products', value: `${allRows.length} Products`, sub: 'Cleaning & Cosmetics', color: 'text-white' },
        { label: 'Cleaning Products', value: `${cleaning.length} Products`, sub: `Val: ₹${cleanWVal.toLocaleString('en-IN', { maximumFractionDigits: 0 })} • ${cleanInStock} In Stock`, color: 'text-emerald-300' },
        { label: 'Cosmetic Products', value: `${cosmetics.length} Products`, sub: `Val: ₹${cosWVal.toLocaleString('en-IN', { maximumFractionDigits: 0 })} • ${cosInStock} In Stock`, color: 'text-pink-300' },
        { label: 'Total Stock Value (Wholesale)', value: `₹${totalWholesaleVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, sub: 'Purchase / Cost Value', color: 'text-emerald-400' },
        { label: 'Potential Retail Value', value: `₹${totalRetailVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, sub: 'Expected Sales Revenue', color: 'text-amber-300' },
        { label: 'Low Stock Alert', value: `${lowStockCount} Products`, sub: 'Stock ≤ 5 units', color: lowStockCount > 0 ? 'text-rose-400' : 'text-emerald-400' }
    ];

    const summaryHtml = summaryCards.map(c => `
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-3 shadow-xs">
            <div class="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">${c.label}</div>
            <b class="text-sm sm:text-base ${c.color || 'text-white'} font-black block mt-0.5">${c.value}</b>
            <span class="text-[10px] text-slate-500 block truncate">${c.sub}</span>
        </div>
    `).join('');
    ['consolidatedStockSummary', 'consolidatedStockSummaryCos'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = summaryHtml;
    });

    const bodyHtml = filteredRows.length ? filteredRows.map((r, i) => {
        const catBadge = r.category === 'Cleaning'
            ? '<span class="bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 px-2 py-0.5 rounded text-[10px] font-bold">🧹 Cleaning</span>'
            : '<span class="bg-pink-950/80 text-pink-300 border border-pink-800/60 px-2 py-0.5 rounded text-[10px] font-bold">💄 Cosmetics</span>';

        const pricingDisplay = `<div class="text-[11px] space-y-0.5"><span class="text-sky-300 font-semibold block">W: ₹${r.wholesalePrice.toFixed(2)}</span><span class="text-emerald-400 font-semibold block">R: ₹${r.retailPrice.toFixed(2)}</span></div>`;

        const stockValuationDisplay = `<span class="font-mono font-bold text-xs text-emerald-400">₹${r.wholesaleValuation.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>`;

        const stockClass = r.isLowStock ? 'text-rose-400 font-black' : 'text-slate-100 font-bold';
        const statusBadge = r.isLowStock
            ? `<span class="bg-rose-950/80 text-rose-300 border border-rose-800/60 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase whitespace-nowrap">⚠️ Low Stock (${r.stock} ${r.unit})</span>`
            : `<span class="bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase whitespace-nowrap">✓ ${r.stock} ${r.unit}</span>`;

        return `
            <tr class="border-t border-slate-800 hover:bg-slate-900/50 transition">
                <td class="p-2.5 text-slate-500 font-mono text-xs">${i + 1}</td>
                <td class="p-2.5">${catBadge}</td>
                <td class="p-2.5 min-w-[180px]">
                    <span class="font-bold text-slate-100 text-xs">${r.name || '—'}</span>
                </td>
                <td class="p-2.5 text-right ${stockClass} text-xs font-mono font-bold">${r.stock}</td>
                <td class="p-2.5 text-slate-300 text-xs font-semibold">${r.unit || '—'}</td>
                <td class="p-2.5">${pricingDisplay}</td>
                <td class="p-2.5 text-right">${stockValuationDisplay}</td>
                <td class="p-2.5 text-slate-400 font-mono text-[11px]">${r.barcode || '—'}</td>
                <td class="p-2.5 text-center">${statusBadge}</td>
            </tr>
        `;
    }).join('') : `<tr><td colspan="9" class="p-6 text-center text-slate-500 text-xs">No products match the selected filter.</td></tr>`;

    ['consolidatedStockTableBody', 'consolidatedStockTableBodyCos'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = bodyHtml;
    });

    // Product-only Unit Totals (No package units mixed)
    const unitMap = {};
    filteredRows.forEach(r => {
        const u = r.unit || 'No Unit';
        unitMap[u] = (unitMap[u] || 0) + r.stock;
    });
    const unitHtml = Object.entries(unitMap).sort((a, b) => a[0].localeCompare(b[0])).map(([u, total]) => `
        <div class="flex justify-between items-center bg-slate-900/80 border border-slate-800 rounded-xl px-3.5 py-2 text-xs">
            <span class="text-slate-400 font-medium">Total ${u}</span>
            <b class="text-slate-100 font-bold font-mono">${Number(total.toFixed(2))} ${u}</b>
        </div>
    `).join('') || '<div class="text-[10px] text-slate-500">No stock data available.</div>';

    ['consolidatedStockUnitTotals', 'consolidatedStockUnitTotalsCos'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = unitHtml;
    });

    // Dedicated Stock Valuation Banner
    const valuationBannerHtml = `
        <div class="bg-slate-900/90 border border-emerald-900/50 rounded-xl p-4 shadow-sm">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                    <h4 class="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                        <span>💰</span> Total Product Stock Valuation
                    </h4>
                    <p class="text-[11px] text-slate-400 mt-0.5">Calculated at base wholesale & retail pricing across all products</p>
                </div>
                <div class="flex flex-wrap items-center gap-3 text-xs">
                    <div class="bg-slate-950/80 px-3.5 py-2 rounded-lg border border-slate-800">
                        <span class="text-slate-400 text-[10px] block">Wholesale Stock Value</span>
                        <b class="text-emerald-400 font-mono text-sm sm:text-base">₹${totalWholesaleVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</b>
                    </div>
                    <div class="bg-slate-950/80 px-3.5 py-2 rounded-lg border border-slate-800">
                        <span class="text-slate-400 text-[10px] block">Potential Retail Value</span>
                        <b class="text-amber-300 font-mono text-sm sm:text-base">₹${totalRetailVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</b>
                    </div>
                </div>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-800/80 text-xs">
                <div class="flex justify-between items-center bg-slate-950/50 px-3 py-2 rounded-lg">
                    <span class="text-slate-300 flex items-center gap-1.5">🧹 Cleaning Stock Valuation:</span>
                    <b class="text-emerald-300 font-mono font-bold">₹${cleanWVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</b>
                </div>
                <div class="flex justify-between items-center bg-slate-950/50 px-3 py-2 rounded-lg">
                    <span class="text-slate-300 flex items-center gap-1.5">💄 Cosmetics Stock Valuation:</span>
                    <b class="text-pink-300 font-mono font-bold">₹${cosWVal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</b>
                </div>
            </div>
        </div>
    `;
    ['consolidatedStockValuationBanner', 'consolidatedStockValuationBannerCos'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = valuationBannerHtml;
    });

    // Update Category Pill Button Active Styles (all, cleaning, cosmetics)
    ['clean', 'cos'].forEach(prefix => {
        const container = document.getElementById(prefix === 'cos' ? 'cosStockConsolidatedFilterPills' : 'cleanStockConsolidatedFilterPills');
        if (container) {
            container.querySelectorAll('button[data-cat]').forEach(btn => {
                const btnCat = btn.getAttribute('data-cat');
                if (btnCat === currentConsolidatedCategory) {
                    btn.className = 'px-3 py-1.5 rounded-xl bg-emerald-700 text-white font-bold text-xs shadow-sm transition';
                } else {
                    btn.className = 'px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold transition';
                }
            });
        }
    });
}

export function viewProduct(id) {
    const p = state.products.find(x => x.id === id);
    if (!p) return;
    const variantsHtml = (p.variants && p.variants.length > 0)
        ? `<div class="mt-3 pt-2 border-t border-slate-800"><p class="font-bold text-slate-100 text-xs mb-1.5">📦 Configured Pack Sizes & Rates:</p><div class="space-y-1.5">` +
        p.variants.map(v => `<div class="bg-slate-900/80 p-2 rounded-lg text-xs flex justify-between items-center border border-slate-800"><div><span class="font-bold text-white">${v.name}</span> <span class="text-slate-400">(${v.size} ${v.unit}${v.packageName ? ' • ' + v.packageName : ''})</span></div><div class="text-right">W: <span class="text-sky-300 font-bold">₹${v.wholesalePrice}</span> | R: <span class="text-emerald-400 font-bold">₹${v.retailPrice}</span></div></div>`).join('') +
        `</div></div>`
        : '';
    if (typeof window.showRecordView === 'function') {
        window.showRecordView('Product Details', `<div class="space-y-2"><p><b>Product:</b> ${p.name}</p><p><b>Barcode:</b> ${p.barcode || '—'}</p><p><b>Stock:</b> ${p.stock} ${p.unit}</p><p><b>Base Wholesale:</b> ₹${p.wholesalePrice}</p><p><b>Base Retail:</b> ₹${p.retailPrice}</p>${p.packageName ? `<p><b>Default Package:</b> ${p.packageName}</p>` : ''}${variantsHtml}</div><div class="flex gap-2 pt-4 border-t border-slate-800 mt-4 justify-end"><button type="button" onclick="closeRecordView(); editProduct('${p.id}');" class="bg-slate-800 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 hover:bg-slate-700 font-semibold text-xs">Edit</button><button type="button" onclick="closeRecordView(); deleteProduct('${p.id}');" class="bg-slate-800 text-rose-300 hover:bg-rose-950/60 px-3 py-1.5 rounded-lg border border-slate-700 hover:border-rose-800/60 font-semibold text-xs">Delete</button></div>`);
    }
}

export function viewCosProduct(id) {
    const p = state.cosProducts.find(x => x.id === id);
    if (!p) return;
    const variantsHtml = (p.variants && p.variants.length > 0)
        ? `<div class="mt-3 pt-2 border-t border-slate-800"><p class="font-bold text-slate-100 text-xs mb-1.5">📦 Configured Pack Sizes & Rates:</p><div class="space-y-1.5">` +
        p.variants.map(v => `<div class="bg-slate-900/80 p-2 rounded-lg text-xs flex justify-between items-center border border-slate-800"><div><span class="font-bold text-white">${v.name}</span> <span class="text-slate-400">(${v.size} ${v.unit}${v.packageName ? ' • ' + v.packageName : ''})</span></div><div class="text-right">W: <span class="text-sky-300 font-bold">₹${v.wholesalePrice !== undefined ? v.wholesalePrice : v.costPrice}</span> | R: <span class="text-emerald-400 font-bold">₹${v.retailPrice !== undefined ? v.retailPrice : v.salePrice}</span></div></div>`).join('') +
        `</div></div>`
        : '';
    if (typeof window.showRecordView === 'function') {
        window.showRecordView('Cosmetic Product Details', `<div class="space-y-2"><p><b>Product:</b> ${p.name}</p><p><b>Barcode:</b> ${p.barcode || '—'}</p><p><b>Stock:</b> ${p.stock} ${p.unit}</p><p><b>Base Wholesale:</b> ₹${p.costPrice}</p><p><b>Base Retail:</b> ₹${p.salePrice}</p>${p.packageName ? `<p><b>Default Package:</b> ${p.packageName}</p>` : ''}${variantsHtml}</div><div class="flex gap-2 pt-4 border-t border-slate-800 mt-4 justify-end"><button type="button" onclick="closeRecordView(); editCosProduct('${p.id}');" class="bg-slate-800 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 hover:bg-slate-700 font-semibold text-xs">Edit</button><button type="button" onclick="closeRecordView(); deleteCosProduct('${p.id}');" class="bg-slate-800 text-rose-300 hover:bg-rose-950/60 px-3 py-1.5 rounded-lg border border-slate-700 hover:border-rose-800/60 font-semibold text-xs">Delete</button></div>`);
    }
}

export function viewPackage(id) {
    const x = state.packages.find(p => String(p.id) === String(id));
    if (!x) return;
    const isLow = (Number(x.stock) || 0) <= 5;
    const statusBadge = isLow
        ? `<span class="bg-rose-950/80 text-rose-300 border border-rose-800/60 px-2 py-0.5 rounded text-[10px] font-bold uppercase whitespace-nowrap">⚠️ LOW STOCK: ${x.stock ?? 0} ${x.unit || 'Pcs'}</span>`
        : `<span class="bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 px-2 py-0.5 rounded text-[10px] font-bold uppercase whitespace-nowrap font-mono">✓ ${x.stock ?? 0} ${x.unit || 'Pcs'}</span>`;
    if (typeof window.showRecordView === 'function') {
        window.showRecordView('Package Item Details', `<div class="space-y-2"><p><b>Package Name:</b> ${x.name}</p><p><b>Size / Volume:</b> ${x.size || '—'}</p><p><b>Unit:</b> ${x.unit || 'Pcs'}</p><p><b>Available Stock:</b> <span class="${isLow ? 'text-rose-400 font-bold' : 'text-emerald-300 font-bold'} font-mono">${x.stock ?? 0} ${x.unit || 'Pcs'}</span></p><p><b>Status:</b> ${statusBadge}</p></div><div class="flex gap-2 pt-4 border-t border-slate-800 mt-4 justify-end"><button type="button" onclick="closeRecordView(); editPackage('${x.id}');" class="bg-slate-800 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 hover:bg-slate-700 font-semibold text-xs">Edit</button><button type="button" onclick="closeRecordView(); deletePackage('${x.id}');" class="bg-slate-800 text-rose-300 hover:bg-rose-950/60 px-3 py-1.5 rounded-lg border border-slate-700 hover:border-rose-800/60 font-semibold text-xs">Delete</button></div>`);
    }
}

// Global window bindings for HTML inline onclick attributes
if (typeof window !== 'undefined') {
    window.updatePackageSelectors = updatePackageSelectors;
    window.addProductVariantRow = addProductVariantRow;
    window.addPresetProductVariant = addPresetProductVariant;
    window.getProductFormVariants = getProductFormVariants;
    window.renderProductVariants = renderProductVariants;
    window.clearProductVariants = clearProductVariants;
    window.normalizePackageMapping = normalizePackageMapping;
    window.switchPackageActionTab = switchPackageActionTab;
    window.switchStockTopTab = switchStockTopTab;
    window.switchStockSubTab = switchStockSubTab;
    window.switchStockActionTab = switchStockActionTab;
    window.savePackage = savePackage;
    window.resetPackageForm = resetPackageForm;
    window.editPackage = editPackage;
    window.deletePackage = deletePackage;
    window.addPackageStock = addPackageStock;
    window.renderPackages = renderPackages;
    window.switchPackageView = switchPackageView;
    window.renderPackageConsolidationReport = renderPackageConsolidationReport;
    window.getProductPackageInfo = getProductPackageInfo;
    window.getPackageSellingUnits = getPackageSellingUnits;
    window.resolvePackageInfoForItem = resolvePackageInfoForItem;
    window.restorePackageStock = restorePackageStock;
    window.checkAndDeductPackageStock = checkAndDeductPackageStock;
    window.saveProduct = saveProduct;
    window.addCleaningStock = addCleaningStock;
    window.saveStockReturn = saveStockReturn;
    window.updateStockReturnDropdowns = updateStockReturnDropdowns;
    window.renderStockReturnHistory = renderStockReturnHistory;
    window.toggleStockReturnMode = toggleStockReturnMode;
    window.onStockReturnBillSelected = onStockReturnBillSelected;
    window.onStockReturnItemSelected = onStockReturnItemSelected;
    window.onStockReturnDirectProductSelected = onStockReturnDirectProductSelected;
    window.setStockReturnPreset = setStockReturnPreset;
    window.calculateStockReturnPreview = calculateStockReturnPreview;
    window.renderProducts = renderProducts;
    window.editProduct = editProduct;
    window.deleteProduct = deleteProduct;
    window.resetProductForm = resetProductForm;
    window.saveCosProduct = saveCosProduct;
    window.addCosmeticStock = addCosmeticStock;
    window.editCosProduct = editCosProduct;
    window.deleteCosProduct = deleteCosProduct;
    window.renderCosProductStock = renderCosProductStock;
    window.resetCosProductForm = resetCosProductForm;
    window.updateCosProductDropdowns = updateCosProductDropdowns;
    window.updateCleaningAddStockDropdown = updateCleaningAddStockDropdown;
    window.renderConsolidatedStockReport = renderConsolidatedStockReport;
    window.setConsolidatedStockCategory = setConsolidatedStockCategory;
    window.onConsolidatedStockSearch = onConsolidatedStockSearch;
    window.shareConsolidatedStockWhatsApp = shareConsolidatedStockWhatsApp;
    window.switchStockTopTab = switchStockTopTab;
    window.switchStockSubTab = switchStockSubTab;
    window.switchStockActionTab = switchStockActionTab;
    window.viewProduct = viewProduct;
    window.viewCosProduct = viewCosProduct;
    window.viewPackage = viewPackage;
}

